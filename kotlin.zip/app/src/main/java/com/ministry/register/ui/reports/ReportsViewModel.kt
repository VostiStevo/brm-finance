package com.ministry.register.ui.reports

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ministry.register.data.repository.MemberRepository
import com.ministry.register.data.repository.TransactionRepository
import com.ministry.register.data.settings.SettingsRepository
import com.ministry.register.data.util.BackupManager
import com.ministry.register.data.util.CsvExporter
import com.ministry.register.data.util.PdfReportGenerator
import com.ministry.register.data.util.RestoreMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

data class ReportsUiState(
    val memberCount: Int = 0,
    val transactionCount: Int = 0,
    val isBusy: Boolean = false,
    val lastExportedFile: File? = null,
    val message: String? = null
)

class ReportsViewModel(
    private val context: android.content.Context,
    private val memberRepository: MemberRepository,
    private val transactionRepository: TransactionRepository,
    private val settingsRepository: SettingsRepository,
    private val pdfReportGenerator: PdfReportGenerator,
    private val backupManager: BackupManager
) : ViewModel() {

    private val _state = MutableStateFlow(ReportsUiState())
    val state: StateFlow<ReportsUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            _state.value = _state.value.copy(
                memberCount = memberRepository.getAll().size,
                transactionCount = transactionRepository.getAll().size
            )
        }
    }

    fun exportMembersPdf() = runExport {
        val members = memberRepository.getAll()
        val settings = settingsRepository.current()
        pdfReportGenerator.generateMemberReport(members, settings)
    }

    fun exportMembersCsv() = runExport {
        val members = memberRepository.getAll()
        val settings = settingsRepository.current()
        CsvExporter.exportMembers(context, members, settings)
    }

    fun exportLedgerPdf(periodLabel: String = "All Time") = runExport {
        val txns = transactionRepository.getAll()
        val settings = settingsRepository.current()
        pdfReportGenerator.generateLedgerReport(txns, settings, periodLabel)
    }

    fun exportLedgerCsv() = runExport {
        val txns = transactionRepository.getAll()
        CsvExporter.exportTransactions(context, txns)
    }

    fun exportFullBackup() = runExport { backupManager.exportBackup() }

    fun restoreBackup(file: File, mode: RestoreMode) {
        viewModelScope.launch {
            _state.value = _state.value.copy(isBusy = true, message = null)
            runCatching {
                val payload = backupManager.readBackup(file)
                backupManager.restore(payload, mode)
            }.onSuccess {
                _state.value = _state.value.copy(isBusy = false, message = "Backup restored successfully.")
            }.onFailure {
                _state.value = _state.value.copy(isBusy = false, message = "Restore failed: ${it.message}")
            }
        }
    }

    private fun runExport(block: suspend () -> File) {
        viewModelScope.launch {
            _state.value = _state.value.copy(isBusy = true, message = null)
            runCatching { block() }
                .onSuccess { file -> _state.value = _state.value.copy(isBusy = false, lastExportedFile = file, message = "Export ready.") }
                .onFailure { _state.value = _state.value.copy(isBusy = false, message = "Export failed: ${it.message}") }
        }
    }

    fun clearMessage() {
        _state.value = _state.value.copy(message = null)
    }
}
