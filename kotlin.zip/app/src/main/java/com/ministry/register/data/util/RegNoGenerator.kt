package com.ministry.register.data.util

object RegNoGenerator {
    /**
     * Suggests the next registration number based only on currently-existing
     * (non-deleted) members. Since a deleted member's regNo is no longer in
     * [existingRegNos], deleting the highest-numbered record frees that
     * number up again, while deleting one from the middle leaves the running
     * max — and therefore the next suggested number — unaffected.
     */
    fun next(existingRegNos: List<String>, prefix: String, digits: Int): String {
        var max = 0
        for (raw in existingRegNos) {
            val rn = raw.trim()
            if (!rn.startsWith(prefix)) continue
            val rest = rn.substring(prefix.length)
            val n = rest.toIntOrNull() ?: continue
            if (n > max) max = n
        }
        return prefix + (max + 1).toString().padStart(digits, '0')
    }
}
