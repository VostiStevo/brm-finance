package com.ministry.register

import android.app.Application
import com.ministry.register.data.db.AppDatabase
import com.ministry.register.data.repository.MemberRepository
import com.ministry.register.data.repository.TransactionRepository
import com.ministry.register.data.security.SecurityManager
import com.ministry.register.data.settings.SettingsRepository
import com.ministry.register.data.util.BackupManager
import com.ministry.register.data.util.PdfReportGenerator

class MinistryApp : Application() {

    lateinit var database: AppDatabase
        private set
    lateinit var settingsRepository: SettingsRepository
        private set
    lateinit var memberRepository: MemberRepository
        private set
    lateinit var transactionRepository: TransactionRepository
        private set
    lateinit var securityManager: SecurityManager
        private set
    lateinit var pdfReportGenerator: PdfReportGenerator
        private set
    lateinit var backupManager: BackupManager
        private set

    override fun onCreate() {
        super.onCreate()
        database = AppDatabase.get(this)
        settingsRepository = SettingsRepository(this)
        memberRepository = MemberRepository(database.memberDao(), settingsRepository)
        transactionRepository = TransactionRepository(database.transactionDao())
        securityManager = SecurityManager(this, settingsRepository)
        pdfReportGenerator = PdfReportGenerator(this)
        backupManager = BackupManager(this, memberRepository, transactionRepository, settingsRepository)
    }
}
