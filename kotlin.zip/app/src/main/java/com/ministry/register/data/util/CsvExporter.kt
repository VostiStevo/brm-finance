package com.ministry.register.data.util

import android.content.Context
import com.ministry.register.data.db.entity.MemberEntity
import com.ministry.register.data.db.entity.TransactionEntity
import com.ministry.register.data.db.entity.TxnKind
import com.ministry.register.data.settings.AppSettings
import java.io.File

object CsvExporter {

    private fun escape(value: String): String {
        val needsQuoting = value.contains(',') || value.contains('"') || value.contains('\n')
        val escaped = value.replace("\"", "\"\"")
        return if (needsQuoting) "\"$escaped\"" else escaped
    }

    private fun toCsv(headers: List<String>, rows: List<List<String>>): String {
        val sb = StringBuilder()
        sb.append(headers.joinToString(",") { escape(it) }).append("\n")
        for (row in rows) sb.append(row.joinToString(",") { escape(it) }).append("\n")
        return sb.toString()
    }

    fun exportMembers(context: Context, members: List<MemberEntity>, settings: AppSettings): File {
        val customLabels = settings.customFields.map { it.id to it.label }
        val headers = listOf("Reg No", "Name", "Gender", "DOB", "Membership Type", "Date Joined", "Expiry", "Notes") +
            customLabels.map { it.second }
        val rows = members.map { m ->
            val custom = JsonCodec.decodeCustomData(m.customDataJson)
            listOf(m.regNo, m.name, m.gender, m.dob, m.membershipType, m.joined, m.membershipExpiry, m.notes) +
                customLabels.map { (id, _) -> custom[id] ?: "" }
        }
        val csv = toCsv(headers, rows)
        val outDir = File(context.cacheDir, "reports").apply { mkdirs() }
        val outFile = File(outDir, "members_${System.currentTimeMillis()}.csv")
        outFile.writeText(csv)
        return outFile
    }

    fun exportTransactions(context: Context, transactions: List<TransactionEntity>): File {
        val headers = listOf("Date", "Type", "Category", "Pay Method", "Amount", "Note")
        val rows = transactions.map {
            listOf(
                it.date,
                if (it.kind == TxnKind.INCOME) "Income" else "Expense",
                it.category, it.payMethod,
                it.amount.toString(),
                it.note
            )
        }
        val csv = toCsv(headers, rows)
        val outDir = File(context.cacheDir, "reports").apply { mkdirs() }
        val outFile = File(outDir, "ledger_${System.currentTimeMillis()}.csv")
        outFile.writeText(csv)
        return outFile
    }
}
