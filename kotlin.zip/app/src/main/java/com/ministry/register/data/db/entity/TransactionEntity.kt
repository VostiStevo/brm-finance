package com.ministry.register.data.db.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Serializable
enum class TxnKind { INCOME, EXPENSE }

/** A single income or expense ledger entry. */
@Entity(tableName = "transactions")
@Serializable
data class TransactionEntity(
    @PrimaryKey val id: String,
    val kind: TxnKind,
    val date: String = "",          // ISO yyyy-MM-dd
    val amount: Double = 0.0,
    val category: String = "",
    val payMethod: String = "",
    val memberId: String? = null,   // optional link to a member (e.g. tithe/offering giver)
    val note: String = "",
    val customDataJson: String = "{}",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
