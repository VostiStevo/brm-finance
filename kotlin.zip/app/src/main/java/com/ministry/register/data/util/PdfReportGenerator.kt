package com.ministry.register.data.util

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import com.ministry.register.data.db.entity.MemberEntity
import com.ministry.register.data.db.entity.TransactionEntity
import com.ministry.register.data.db.entity.TxnKind
import com.ministry.register.data.settings.AppSettings
import java.io.File
import java.io.FileOutputStream
import java.text.NumberFormat
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * Draws simple, paginated tabular reports directly onto PDF canvases —
 * a lightweight native stand-in for the web app's jsPDF + autotable export.
 */
class PdfReportGenerator(private val context: Context) {

    private val pageWidth = 595   // A4 @ 72dpi
    private val pageHeight = 842
    private val margin = 32f
    private val rowHeight = 20f

    private fun currency(amount: Double, symbol: String): String {
        val nf = NumberFormat.getNumberInstance(Locale.US)
        nf.minimumFractionDigits = 2
        nf.maximumFractionDigits = 2
        return "$symbol ${nf.format(amount)}"
    }

    fun generateMemberReport(members: List<MemberEntity>, settings: AppSettings): File {
        val headers = listOf("Reg No", "Name", "Gender", "DOB", "Membership")
        val rows = members.map {
            listOf(it.regNo, it.name, it.gender, it.dob, it.membershipType)
        }
        return renderTableReport(
            fileName = "member_records_${System.currentTimeMillis()}.pdf",
            title = "MEMBER RECORDS REPORT",
            subtitle = settings.ministryName,
            headers = headers,
            rows = rows,
            columnWeights = listOf(1.1f, 2.2f, 0.9f, 1.1f, 1.1f),
            footerNote = "Total Records: ${members.size}"
        )
    }

    fun generateLedgerReport(transactions: List<TransactionEntity>, settings: AppSettings, periodLabel: String): File {
        val headers = listOf("Date", "Type", "Category", "Method", "Amount")
        val rows = transactions.map {
            listOf(
                it.date,
                if (it.kind == TxnKind.INCOME) "Income" else "Expense",
                it.category,
                it.payMethod,
                currency(it.amount, settings.currencySymbol)
            )
        }
        val totalIncome = transactions.filter { it.kind == TxnKind.INCOME }.sumOf { it.amount }
        val totalExpense = transactions.filter { it.kind == TxnKind.EXPENSE }.sumOf { it.amount }
        val net = totalIncome - totalExpense
        return renderTableReport(
            fileName = "ledger_${System.currentTimeMillis()}.pdf",
            title = "LEDGER REPORT — $periodLabel",
            subtitle = settings.ministryName,
            headers = headers,
            rows = rows,
            columnWeights = listOf(1f, 0.9f, 1.3f, 1.1f, 1.2f),
            footerNote = "Income: ${currency(totalIncome, settings.currencySymbol)}   " +
                "Expense: ${currency(totalExpense, settings.currencySymbol)}   " +
                "Net: ${currency(net, settings.currencySymbol)}"
        )
    }

    private fun renderTableReport(
        fileName: String,
        title: String,
        subtitle: String,
        headers: List<String>,
        rows: List<List<String>>,
        columnWeights: List<Float>,
        footerNote: String
    ): File {
        val document = PdfDocument()
        val titlePaint = Paint().apply { textSize = 16f; isFakeBoldText = true; color = Color.BLACK }
        val subPaint = Paint().apply { textSize = 10f; color = Color.DKGRAY }
        val headerPaint = Paint().apply { textSize = 9.5f; isFakeBoldText = true; color = Color.WHITE }
        val headerBgPaint = Paint().apply { color = Color.parseColor("#132420") }
        val cellPaint = Paint().apply { textSize = 9f; color = Color.BLACK }
        val lineePaint = Paint().apply { color = Color.LTGRAY; strokeWidth = 0.5f }
        val footerPaint = Paint().apply { textSize = 8f; color = Color.GRAY }

        val usableWidth = pageWidth - margin * 2
        val totalWeight = columnWeights.sum()
        val colWidths = columnWeights.map { usableWidth * (it / totalWeight) }

        var pageNumber = 0
        var rowIndex = 0
        val timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd MMM yyyy, HH:mm"))

        while (rowIndex < rows.size || pageNumber == 0) {
            pageNumber++
            val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
            val page = document.startPage(pageInfo)
            val canvas: Canvas = page.canvas
            var y = margin

            canvas.drawText(title, margin, y + 14f, titlePaint)
            y += 20f
            canvas.drawText(subtitle, margin, y + 10f, subPaint)
            y += 14f
            canvas.drawText("Generated: $timestamp", margin, y + 10f, subPaint)
            y += 20f

            // table header
            canvas.drawRect(margin, y, margin + usableWidth, y + rowHeight, headerBgPaint)
            var x = margin
            headers.forEachIndexed { i, h ->
                canvas.drawText(h, x + 4f, y + rowHeight - 6f, headerPaint)
                x += colWidths[i]
            }
            y += rowHeight

            val maxY = pageHeight - margin - 30f
            while (rowIndex < rows.size && y + rowHeight <= maxY) {
                val row = rows[rowIndex]
                x = margin
                row.forEachIndexed { i, cell ->
                    canvas.drawText(truncate(cell, colWidths[i], cellPaint), x + 4f, y + rowHeight - 6f, cellPaint)
                    x += colWidths[i]
                }
                canvas.drawLine(margin, y + rowHeight, margin + usableWidth, y + rowHeight, lineePaint)
                y += rowHeight
                rowIndex++
            }

            canvas.drawText(footerNote, margin, pageHeight - margin, footerPaint)
            canvas.drawText("Page $pageNumber", pageWidth - margin - 50f, pageHeight - margin, footerPaint)

            document.finishPage(page)
        }

        val outDir = File(context.cacheDir, "reports").apply { mkdirs() }
        val outFile = File(outDir, fileName)
        FileOutputStream(outFile).use { document.writeTo(it) }
        document.close()
        return outFile
    }

    private fun truncate(text: String, maxWidth: Float, paint: Paint): String {
        if (paint.measureText(text) <= maxWidth - 6f) return text
        var end = text.length
        while (end > 0 && paint.measureText(text.substring(0, end) + "…") > maxWidth - 6f) end--
        return if (end <= 0) "" else text.substring(0, end) + "…"
    }
}
