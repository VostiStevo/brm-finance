package com.ministry.register.ui.members

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ministry.register.data.db.entity.FamilyMember
import com.ministry.register.data.db.entity.MemberEntity
import com.ministry.register.data.db.entity.RepeatingRow
import com.ministry.register.data.repository.MemberRepository
import com.ministry.register.data.settings.AppSettings
import com.ministry.register.data.settings.SettingsRepository
import com.ministry.register.data.util.AgeUtils
import com.ministry.register.data.util.Ids
import com.ministry.register.data.util.JsonCodec
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class MemberFormState(
    val id: String? = null,
    val name: String = "",
    val gender: String = "Male",
    val dob: String = "",
    val regNo: String = "",
    val membershipType: String = "Regular",
    val joined: String = AgeUtils.todayIso(),
    val membershipExpiry: String = "",
    val familyMembers: List<FamilyMember> = emptyList(),
    val notes: String = "",
    val customData: Map<String, String> = emptyMap(),
    val repeatingData: Map<String, List<RepeatingRow>> = emptyMap(),
    val settings: AppSettings = AppSettings(),
    val isLoading: Boolean = true,
    val errorMessage: String? = null,
    val duplicateOf: MemberEntity? = null,
    val saved: Boolean = false
) {
    val age: Int? get() = AgeUtils.calcAge(dob)
}

class MemberFormViewModel(
    private val repository: MemberRepository,
    private val settingsRepository: SettingsRepository,
    private val memberId: String?
) : ViewModel() {

    private val _state = MutableStateFlow(MemberFormState(id = memberId))
    val state: StateFlow<MemberFormState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            val settings = settingsRepository.current()
            val existing = memberId?.let { repository.getById(it) }
            if (existing != null) {
                val decodedCustom = JsonCodec.decodeCustomData(existing.customDataJson).toMutableMap()
                val repeatingFieldIds = settings.customFields.filter { it.type == com.ministry.register.data.settings.FieldType.REPEATING }.map { it.id }
                val repeatingData = mutableMapOf<String, List<RepeatingRow>>()
                repeatingFieldIds.forEach { fid ->
                    decodedCustom[fid]?.let { raw ->
                        repeatingData[fid] = JsonCodec.decodeRepeatingRows(raw)
                        decodedCustom.remove(fid)
                    }
                }
                _state.value = MemberFormState(
                    id = existing.id,
                    name = existing.name,
                    gender = existing.gender,
                    dob = existing.dob,
                    regNo = existing.regNo,
                    membershipType = existing.membershipType,
                    joined = existing.joined,
                    membershipExpiry = existing.membershipExpiry,
                    familyMembers = JsonCodec.decodeFamilyMembers(existing.familyMembersJson),
                    notes = existing.notes,
                    customData = decodedCustom,
                    repeatingData = repeatingData,
                    settings = settings,
                    isLoading = false
                )
            } else {
                _state.value = _state.value.copy(
                    settings = settings,
                    regNo = repository.suggestNextRegNo(),
                    isLoading = false
                )
            }
        }
    }

    fun update(transform: (MemberFormState) -> MemberFormState) {
        _state.value = transform(_state.value)
    }

    fun setCustomField(fieldId: String, value: String) {
        _state.value = _state.value.copy(customData = _state.value.customData + (fieldId to value))
    }

    fun addFamilyRow() {
        _state.value = _state.value.copy(familyMembers = _state.value.familyMembers + FamilyMember())
    }

    fun updateFamilyRow(index: Int, member: FamilyMember) {
        val list = _state.value.familyMembers.toMutableList()
        if (index in list.indices) list[index] = member
        _state.value = _state.value.copy(familyMembers = list)
    }

    fun removeFamilyRow(index: Int) {
        val list = _state.value.familyMembers.toMutableList()
        if (index in list.indices) list.removeAt(index)
        _state.value = _state.value.copy(familyMembers = list)
    }

    fun addRepeatingRow(fieldId: String) {
        val current = _state.value.repeatingData[fieldId] ?: emptyList()
        _state.value = _state.value.copy(repeatingData = _state.value.repeatingData + (fieldId to (current + RepeatingRow())))
    }

    fun updateRepeatingRow(fieldId: String, index: Int, row: RepeatingRow) {
        val list = (_state.value.repeatingData[fieldId] ?: emptyList()).toMutableList()
        if (index in list.indices) list[index] = row
        _state.value = _state.value.copy(repeatingData = _state.value.repeatingData + (fieldId to list))
    }

    fun removeRepeatingRow(fieldId: String, index: Int) {
        val list = (_state.value.repeatingData[fieldId] ?: emptyList()).toMutableList()
        if (index in list.indices) list.removeAt(index)
        _state.value = _state.value.copy(repeatingData = _state.value.repeatingData + (fieldId to list))
    }

    /** Returns true if a duplicate was found and save was withheld pending confirmation. */
    fun save(forceSaveDuplicate: Boolean = false, onSaved: () -> Unit) {
        val s = _state.value
        if (s.name.isBlank()) { _state.value = s.copy(errorMessage = "Full name is required."); return }
        if (s.dob.isBlank()) { _state.value = s.copy(errorMessage = "Date of birth is required."); return }

        viewModelScope.launch {
            if (s.regNo.isNotBlank()) {
                val clash = repository.findRegNoClash(s.regNo, s.id)
                if (clash != null) {
                    _state.value = s.copy(errorMessage = "Registration number \"${s.regNo}\" is already used by ${clash.name}.")
                    return@launch
                }
            }

            val mergedCustomData = s.customData.toMutableMap()
            // Fold repeating-field rows into the same customData map, JSON-encoded per field id,
            // so repeating and scalar custom fields share one storage column.
            s.repeatingData.forEach { (fieldId, rows) ->
                val nonEmpty = rows.filter { it.type.isNotBlank() || it.value.isNotBlank() }
                mergedCustomData[fieldId] = JsonCodec.encodeRepeatingRows(nonEmpty)
            }
            val fullCustomDataJson = JsonCodec.encodeCustomData(mergedCustomData)

            val entity = MemberEntity(
                id = s.id ?: Ids.next(),
                name = s.name.trim().uppercase(),
                gender = s.gender,
                dob = s.dob,
                regNo = s.regNo,
                membershipType = s.membershipType,
                joined = s.joined,
                membershipExpiry = s.membershipExpiry,
                familyMembersJson = JsonCodec.encodeFamilyMembers(s.familyMembers.filter { it.name.isNotBlank() }),
                notes = s.notes,
                customDataJson = fullCustomDataJson
            )

            if (!forceSaveDuplicate) {
                val dup = repository.findDuplicate(entity, s.id)
                if (dup != null) {
                    _state.value = s.copy(duplicateOf = dup)
                    return@launch
                }
            }

            repository.save(entity)
            _state.value = s.copy(saved = true, errorMessage = null, duplicateOf = null)
            onSaved()
        }
    }

    fun dismissDuplicateWarning() {
        _state.value = _state.value.copy(duplicateOf = null)
    }
}
