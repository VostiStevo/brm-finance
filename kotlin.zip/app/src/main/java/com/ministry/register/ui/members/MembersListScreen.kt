package com.ministry.register.ui.members

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ministry.register.data.db.entity.MemberEntity
import com.ministry.register.data.util.AgeUtils
import com.ministry.register.ui.components.ConfirmDialog
import com.ministry.register.ui.components.EmptyState
import com.ministry.register.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MembersListScreen(
    viewModel: MembersViewModel,
    onAddMember: () -> Unit,
    onOpenMember: (String) -> Unit
) {
    val state by viewModel.state.collectAsState()
    var confirmBulkDelete by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Members (${state.members.size})") }, actions = {
                if (state.members.isNotEmpty()) {
                    TextButton(onClick = { viewModel.toggleSelectMode() }) {
                        Text(if (state.selectMode) "Cancel" else "Select")
                    }
                }
            })
        },
        floatingActionButton = {
            if (!state.selectMode) {
                FloatingActionButton(onClick = onAddMember, containerColor = Gold, contentColor = Cover2) {
                    Icon(Icons.Default.Add, contentDescription = "Add member")
                }
            }
        },
        bottomBar = {
            if (state.selectMode && state.selectedIds.isNotEmpty()) {
                BottomAppBar {
                    Text("${state.selectedIds.size} selected", modifier = Modifier.padding(start = 16.dp).weight(1f))
                    TextButton(onClick = { confirmBulkDelete = true }) {
                        Icon(Icons.Default.Delete, contentDescription = null, tint = ExpenseColor)
                        Text("Delete", color = ExpenseColor)
                    }
                }
            }
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            OutlinedTextField(
                value = state.query,
                onValueChange = viewModel::setQuery,
                placeholder = { Text("Search name, reg no, gender") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(12.dp)
            )

            if (state.members.isEmpty()) {
                EmptyState("No members yet. Tap + to add your first record.")
            } else {
                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    items(state.members, key = { it.id }) { member ->
                        MemberRow(
                            member = member,
                            warningDays = state.settings.renewalWarningDays,
                            selectMode = state.selectMode,
                            selected = member.id in state.selectedIds,
                            onClick = {
                                if (state.selectMode) viewModel.toggleSelect(member.id) else onOpenMember(member.id)
                            }
                        )
                    }
                    item { Spacer(Modifier.height(96.dp)) }
                }
            }
        }
    }

    if (confirmBulkDelete) {
        ConfirmDialog(
            message = "Delete ${state.selectedIds.size} member record(s)? This cannot be undone.",
            onConfirm = { confirmBulkDelete = false; viewModel.deleteSelected {} },
            onDismiss = { confirmBulkDelete = false }
        )
    }
}

@Composable
private fun MemberRow(
    member: MemberEntity,
    warningDays: Int,
    selectMode: Boolean,
    selected: Boolean,
    onClick: () -> Unit
) {
    val (statusLabel, statusColor) = MembershipStatus.label(member, warningDays)
    val age = AgeUtils.calcAge(member.dob)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(if (selected) Gold.copy(alpha = 0.12f) else Page)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(member.name.ifBlank { "(unnamed)" }, fontWeight = FontWeight.SemiBold)
            Text(
                listOfNotNull(
                    member.regNo.ifBlank { null },
                    member.gender,
                    age?.let { "$it yrs" }
                ).joinToString(" · "),
                style = MaterialTheme.typography.labelSmall,
                color = MutedColor
            )
        }
        Box(
            modifier = Modifier
                .background(statusColor.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            Text(statusLabel, color = statusColor, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
        }
    }
    Divider(color = LineColor)
}
