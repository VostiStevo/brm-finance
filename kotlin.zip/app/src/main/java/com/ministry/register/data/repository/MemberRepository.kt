package com.ministry.register.data.repository

import com.ministry.register.data.db.dao.MemberDao
import com.ministry.register.data.db.entity.MemberEntity
import com.ministry.register.data.settings.SettingsRepository
import com.ministry.register.data.util.DuplicateDetector
import com.ministry.register.data.util.RegNoGenerator
import kotlinx.coroutines.flow.Flow

class MemberRepository(
    private val dao: MemberDao,
    private val settingsRepository: SettingsRepository
) {
    fun observeAll(): Flow<List<MemberEntity>> = dao.observeAll()
    fun observeCount(): Flow<Int> = dao.observeCount()
    fun search(query: String): Flow<List<MemberEntity>> = dao.search(query)

    suspend fun getById(id: String): MemberEntity? = dao.getById(id)
    suspend fun getAll(): List<MemberEntity> = dao.getAll()

    suspend fun suggestNextRegNo(): String {
        val settings = settingsRepository.current()
        val existing = dao.getAllRegNos()
        return RegNoGenerator.next(existing, settings.regNoPrefix, settings.regNoDigits)
    }

    /** Returns the conflicting record if this would be a duplicate, otherwise null. */
    suspend fun findDuplicate(candidate: MemberEntity, excludeId: String?): MemberEntity? =
        DuplicateDetector.findMemberDuplicate(candidate, dao.getAll(), excludeId)

    /** Returns the conflicting record if this regNo is already used by another member. */
    suspend fun findRegNoClash(regNo: String, excludeId: String?): MemberEntity? {
        if (regNo.isBlank()) return null
        return dao.getAll().firstOrNull { it.id != excludeId && it.regNo == regNo }
    }

    suspend fun save(member: MemberEntity) = dao.upsert(member)
    suspend fun delete(id: String) = dao.deleteById(id)
    suspend fun deleteMany(ids: List<String>) = dao.deleteByIds(ids)
}
