package com.ministry.register.ui.finances

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ministry.register.data.db.entity.TransactionEntity
import com.ministry.register.data.db.entity.TxnKind
import com.ministry.register.ui.components.ConfirmDialog
import com.ministry.register.ui.components.EmptyState
import com.ministry.register.ui.theme.*
import java.text.NumberFormat
import java.util.Locale

private fun formatMoney(amount: Double, symbol: String): String {
    val nf = NumberFormat.getNumberInstance(Locale.US)
    nf.minimumFractionDigits = 2
    nf.maximumFractionDigits = 2
    return "$symbol ${nf.format(amount)}"
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FinancesListScreen(
    viewModel: FinancesViewModel,
    onAddTransaction: (TxnKind) -> Unit,
    onOpenTransaction: (TxnKind, String) -> Unit
) {
    val state by viewModel.state.collectAsState()
    var confirmBulkDelete by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Finances") }, actions = {
                if (state.transactions.isNotEmpty()) {
                    TextButton(onClick = { viewModel.toggleSelectMode() }) {
                        Text(if (state.selectMode) "Cancel" else "Select")
                    }
                }
            })
        },
        floatingActionButton = {
            if (!state.selectMode) {
                FloatingActionButton(onClick = { onAddTransaction(state.kind) }, containerColor = Gold, contentColor = Cover2) {
                    Icon(Icons.Default.Add, contentDescription = "Add transaction")
                }
            }
        },
        bottomBar = {
            if (state.selectMode && state.selectedIds.isNotEmpty()) {
                BottomAppBar {
                    Text("${state.selectedIds.size} selected", modifier = Modifier.padding(start = 16.dp).weight(1f))
                    TextButton(onClick = { confirmBulkDelete = true }) {
                        Icon(Icons.Default.Delete, contentDescription = null, tint = ExpenseColor)
                        Text("Delete", color = ExpenseColor)
                    }
                }
            }
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            SegmentedTabs(
                selected = state.kind,
                onSelect = { viewModel.setKind(it) }
            )

            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Total", color = MutedColor)
                Text(
                    formatMoney(state.total, state.settings.currencySymbol),
                    fontWeight = FontWeight.Bold,
                    color = if (state.kind == TxnKind.INCOME) IncomeColor else ExpenseColor
                )
            }

            if (state.transactions.isEmpty()) {
                EmptyState("No ${if (state.kind == TxnKind.INCOME) "income" else "expense"} records yet.")
            } else {
                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    items(state.transactions, key = { it.id }) { txn ->
                        TxnRow(
                            txn = txn,
                            symbol = state.settings.currencySymbol,
                            selectMode = state.selectMode,
                            selected = txn.id in state.selectedIds,
                            onClick = {
                                if (state.selectMode) viewModel.toggleSelect(txn.id) else onOpenTransaction(state.kind, txn.id)
                            }
                        )
                    }
                    item { Spacer(Modifier.height(96.dp)) }
                }
            }
        }
    }

    if (confirmBulkDelete) {
        ConfirmDialog(
            message = "Delete ${state.selectedIds.size} record(s)? This cannot be undone.",
            onConfirm = { confirmBulkDelete = false; viewModel.deleteSelected {} },
            onDismiss = { confirmBulkDelete = false }
        )
    }
}

@Composable
private fun SegmentedTabs(selected: TxnKind, onSelect: (TxnKind) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp)
            .background(androidx.compose.ui.graphics.Color.White, androidx.compose.foundation.shape.RoundedCornerShape(10.dp))
            .padding(4.dp)
    ) {
        listOf(TxnKind.INCOME to "Income", TxnKind.EXPENSE to "Expense").forEach { (k, label) ->
            val isSelected = k == selected
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clickable { onSelect(k) }
                    .background(if (isSelected) Cover else androidx.compose.ui.graphics.Color.Transparent, androidx.compose.foundation.shape.RoundedCornerShape(8.dp))
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(label, color = if (isSelected) Gold else MutedColor, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun TxnRow(
    txn: TransactionEntity,
    symbol: String,
    selectMode: Boolean,
    selected: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(if (selected) Gold.copy(alpha = 0.12f) else Page)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(txn.category.ifBlank { "(uncategorized)" }, fontWeight = FontWeight.SemiBold)
            Text("${txn.date} · ${txn.payMethod}", style = MaterialTheme.typography.labelSmall, color = MutedColor)
        }
        Text(
            formatMoney(txn.amount, symbol),
            fontWeight = FontWeight.Bold,
            color = if (txn.kind == TxnKind.INCOME) IncomeColor else ExpenseColor
        )
    }
    Divider(color = LineColor)
}
