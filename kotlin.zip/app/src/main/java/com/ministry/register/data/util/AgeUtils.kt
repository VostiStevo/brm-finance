package com.ministry.register.data.util

import com.ministry.register.data.settings.AgeGroupBoundary
import java.time.LocalDate
import java.time.Period
import java.time.format.DateTimeFormatter

object AgeUtils {
    private val ISO = DateTimeFormatter.ISO_LOCAL_DATE

    fun parseIso(dateStr: String?): LocalDate? {
        if (dateStr.isNullOrBlank()) return null
        return runCatching { LocalDate.parse(dateStr, ISO) }.getOrNull()
    }

    fun todayIso(): String = LocalDate.now().format(ISO)

    fun calcAge(dobIso: String?): Int? {
        val dob = parseIso(dobIso) ?: return null
        val today = LocalDate.now()
        if (dob.isAfter(today)) return null
        return Period.between(dob, today).years
    }

    fun ageGroup(age: Int?, boundaries: List<AgeGroupBoundary>): String {
        if (age == null) return "—"
        val sorted = boundaries.sortedBy { it.maxAge }
        for (b in sorted) if (age <= b.maxAge) return b.label
        return sorted.lastOrNull()?.label ?: "—"
    }

    /** Days until (positive) or since (negative) a given ISO date, vs. today. */
    fun daysUntil(dateIso: String?): Int? {
        val d = parseIso(dateIso) ?: return null
        return java.time.temporal.ChronoUnit.DAYS.between(LocalDate.now(), d).toInt()
    }
}
