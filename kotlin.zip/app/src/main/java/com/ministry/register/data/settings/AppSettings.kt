package com.ministry.register.data.settings

import kotlinx.serialization.Serializable

enum class FieldType { TEXT, NUMBER, DATE, EMAIL, LIST, REPEATING }

@Serializable
data class CustomFieldDef(
    val id: String,
    val label: String,
    val type: FieldType = FieldType.TEXT,
    val options: List<String> = emptyList(),   // for LIST / REPEATING "type" choices
    val mandatory: Boolean = false,
    val subLabel: String = "",                 // second column label for REPEATING rows
    val condField: String = "",                // id of another field that gates visibility
    val condValue: String = "",                // value condField must equal for this field to show
    val sectionId: String = "additional"        // member-form only; ignored for finance fields
)

@Serializable
data class FormSection(
    val id: String,
    val label: String,
    val core: Boolean = false   // core sections (basic/membership) can be renamed but not deleted
)

@Serializable
data class AgeGroupBoundary(
    val label: String,
    val maxAge: Int   // inclusive upper bound; the last boundary catches everything above
)

@Serializable
data class AppSettings(
    val ministryName: String = "MY MINISTRY",
    val churchName: String = "MEMBERS & FINANCE",
    val currencySymbol: String = "KES",

    val regNoPrefix: String = "REG-",
    val regNoDigits: Int = 4,

    val ageGroupBoundaries: List<AgeGroupBoundary> = listOf(
        AgeGroupBoundary("Child", 12),
        AgeGroupBoundary("Teen", 17),
        AgeGroupBoundary("Youth", 35),
        AgeGroupBoundary("Adult", 200)
    ),

    val renewalWarningDays: Int = 30,

    val memberFormFields: Map<String, Boolean> = mapOf(
        "regNo" to true,
        "membershipType" to true,
        "joined" to true,
        "family" to true,
        "notes" to true,
        "photo" to true
    ),
    val financeFormFields: Map<String, Boolean> = mapOf(
        "payMethod" to true,
        "member" to true,
        "note" to true
    ),

    val incomeCategories: List<String> = listOf("Tithe", "Offering", "Donation", "Fundraising", "Other"),
    val expenseCategories: List<String> = listOf("Utilities", "Maintenance", "Salaries", "Outreach", "Supplies", "Other"),
    val payMethods: List<String> = listOf("Cash", "M-Pesa", "Bank Transfer", "Cheque"),

    val customFields: List<CustomFieldDef> = emptyList(),        // member form
    val financeCustomFields: List<CustomFieldDef> = emptyList(), // income/expense form

    val memberFormSections: List<FormSection> = listOf(
        FormSection("basic", "Basic Details", core = true),
        FormSection("membership", "Membership", core = true),
        FormSection("additional", "Additional Details", core = false)
    ),

    // Security — password/security-question hashes, never the plaintext.
    val securityPasswordHash: String = "",
    val securityPasswordSalt: String = "",
    val securityQuestion: String = "",
    val securityAnswerHash: String = "",
    val securityAnswerSalt: String = "",
    val securityEnabled: Boolean = false
)
