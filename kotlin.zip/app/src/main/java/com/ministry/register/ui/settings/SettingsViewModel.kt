package com.ministry.register.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ministry.register.data.security.SecurityManager
import com.ministry.register.data.settings.AgeGroupBoundary
import com.ministry.register.data.settings.AppSettings
import com.ministry.register.data.settings.CustomFieldDef
import com.ministry.register.data.settings.FormSection
import com.ministry.register.data.settings.SettingsRepository
import com.ministry.register.data.util.Ids
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(
    private val settingsRepository: SettingsRepository,
    private val securityManager: SecurityManager
) : ViewModel() {

    val settings: StateFlow<AppSettings> = settingsRepository.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettings())

    fun updateGeneral(ministryName: String, churchName: String, currencySymbol: String) {
        viewModelScope.launch { settingsRepository.update { it.copy(ministryName = ministryName, churchName = churchName, currencySymbol = currencySymbol) } }
    }

    fun updateRegNo(prefix: String, digits: Int) {
        viewModelScope.launch { settingsRepository.update { it.copy(regNoPrefix = prefix, regNoDigits = digits.coerceIn(1, 10)) } }
    }

    fun updateRenewalWarningDays(days: Int) {
        viewModelScope.launch { settingsRepository.update { it.copy(renewalWarningDays = days.coerceAtLeast(0)) } }
    }

    fun updateAgeGroups(boundaries: List<AgeGroupBoundary>) {
        viewModelScope.launch { settingsRepository.update { it.copy(ageGroupBoundaries = boundaries) } }
    }

    fun updateCategories(income: List<String>, expense: List<String>, payMethods: List<String>) {
        viewModelScope.launch { settingsRepository.update { it.copy(incomeCategories = income, expenseCategories = expense, payMethods = payMethods) } }
    }

    fun toggleMemberField(key: String, on: Boolean) {
        viewModelScope.launch { settingsRepository.update { it.copy(memberFormFields = it.memberFormFields + (key to on)) } }
    }

    fun toggleFinanceField(key: String, on: Boolean) {
        viewModelScope.launch { settingsRepository.update { it.copy(financeFormFields = it.financeFormFields + (key to on)) } }
    }

    // ---- Custom fields ----

    fun saveCustomField(scope: String, def: CustomFieldDef) {
        viewModelScope.launch {
            settingsRepository.update { s ->
                if (scope == "finance") {
                    val list = s.financeCustomFields.toMutableList()
                    val idx = list.indexOfFirst { it.id == def.id }
                    if (idx >= 0) list[idx] = def else list.add(def)
                    s.copy(financeCustomFields = list)
                } else {
                    val list = s.customFields.toMutableList()
                    val idx = list.indexOfFirst { it.id == def.id }
                    if (idx >= 0) list[idx] = def else list.add(def)
                    s.copy(customFields = list)
                }
            }
        }
    }

    fun deleteCustomField(scope: String, id: String) {
        viewModelScope.launch {
            settingsRepository.update { s ->
                if (scope == "finance") s.copy(financeCustomFields = s.financeCustomFields.filterNot { it.id == id })
                else s.copy(customFields = s.customFields.filterNot { it.id == id })
            }
        }
    }

    // ---- Member form sections ----

    fun addSection(label: String) {
        viewModelScope.launch {
            settingsRepository.update { it.copy(memberFormSections = it.memberFormSections + FormSection(Ids.next(), label, core = false)) }
        }
    }

    fun renameSection(id: String, label: String) {
        viewModelScope.launch {
            settingsRepository.update { s ->
                s.copy(memberFormSections = s.memberFormSections.map { if (it.id == id) it.copy(label = label) else it })
            }
        }
    }

    fun deleteSection(id: String) {
        viewModelScope.launch {
            settingsRepository.update { s ->
                val section = s.memberFormSections.firstOrNull { it.id == id } ?: return@update s
                if (section.core) return@update s
                val remaining = s.memberFormSections.filterNot { it.id == id }
                val fallback = remaining.firstOrNull { !it.core } ?: remaining.firstOrNull { it.id == "basic" } ?: remaining.firstOrNull()
                val reassignedFields = s.customFields.map {
                    if ((it.sectionId.ifBlank { "additional" }) == id && fallback != null) it.copy(sectionId = fallback.id) else it
                }
                s.copy(memberFormSections = remaining, customFields = reassignedFields)
            }
        }
    }

    fun moveSection(id: String, direction: Int) {
        viewModelScope.launch {
            settingsRepository.update { s ->
                val list = s.memberFormSections.toMutableList()
                val i = list.indexOfFirst { it.id == id }
                val j = i + direction
                if (i < 0 || j < 0 || j >= list.size) return@update s
                val tmp = list[i]; list[i] = list[j]; list[j] = tmp
                s.copy(memberFormSections = list)
            }
        }
    }

    // ---- Security ----

    fun changePassword(newPassword: String, onDone: (Boolean, String) -> Unit) {
        if (newPassword.length < 4) { onDone(false, "Password must be at least 4 characters."); return }
        viewModelScope.launch {
            securityManager.changePassword(newPassword)
            onDone(true, "Password updated.")
        }
    }

    fun changeSecurityQuestion(question: String, answer: String, onDone: (Boolean, String) -> Unit) {
        if (question.isBlank() || answer.isBlank()) { onDone(false, "Question and answer are both required."); return }
        viewModelScope.launch {
            securityManager.changeSecurityQuestion(question, answer)
            onDone(true, "Recovery question updated.")
        }
    }

    fun disableSecurity(onDone: () -> Unit) {
        viewModelScope.launch { securityManager.disableSecurity(); onDone() }
    }
}
