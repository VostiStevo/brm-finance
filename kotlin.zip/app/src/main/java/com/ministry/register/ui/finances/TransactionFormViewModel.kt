package com.ministry.register.ui.finances

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ministry.register.data.db.entity.TransactionEntity
import com.ministry.register.data.db.entity.TxnKind
import com.ministry.register.data.repository.MemberRepository
import com.ministry.register.data.repository.TransactionRepository
import com.ministry.register.data.settings.AppSettings
import com.ministry.register.data.settings.SettingsRepository
import com.ministry.register.data.util.AgeUtils
import com.ministry.register.data.util.Ids
import com.ministry.register.data.util.JsonCodec
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class TransactionFormState(
    val id: String? = null,
    val kind: TxnKind = TxnKind.INCOME,
    val date: String = AgeUtils.todayIso(),
    val amount: String = "",
    val category: String = "",
    val payMethod: String = "",
    val memberId: String? = null,
    val memberName: String = "",
    val note: String = "",
    val customData: Map<String, String> = emptyMap(),
    val settings: AppSettings = AppSettings(),
    val memberOptions: List<Pair<String, String>> = emptyList(), // id to name
    val isLoading: Boolean = true,
    val errorMessage: String? = null,
    val duplicateOf: TransactionEntity? = null,
    val saved: Boolean = false
)

class TransactionFormViewModel(
    private val repository: TransactionRepository,
    private val memberRepository: MemberRepository,
    private val settingsRepository: SettingsRepository,
    private val kind: TxnKind,
    private val txnId: String?
) : ViewModel() {

    private val _state = MutableStateFlow(TransactionFormState(kind = kind))
    val state: StateFlow<TransactionFormState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            val settings = settingsRepository.current()
            val members = memberRepository.getAll().map { it.id to it.name }
            val defaultCategory = (if (kind == TxnKind.INCOME) settings.incomeCategories else settings.expenseCategories).firstOrNull() ?: ""
            val defaultMethod = settings.payMethods.firstOrNull() ?: ""
            val existing = txnId?.let { repository.getById(it) }

            if (existing != null) {
                _state.value = TransactionFormState(
                    id = existing.id,
                    kind = existing.kind,
                    date = existing.date,
                    amount = if (existing.amount == 0.0) "" else existing.amount.toString(),
                    category = existing.category,
                    payMethod = existing.payMethod,
                    memberId = existing.memberId,
                    memberName = members.firstOrNull { it.first == existing.memberId }?.second ?: "",
                    note = existing.note,
                    customData = JsonCodec.decodeCustomData(existing.customDataJson),
                    settings = settings,
                    memberOptions = members,
                    isLoading = false
                )
            } else {
                _state.value = _state.value.copy(
                    settings = settings,
                    category = defaultCategory,
                    payMethod = defaultMethod,
                    memberOptions = members,
                    isLoading = false
                )
            }
        }
    }

    fun update(transform: (TransactionFormState) -> TransactionFormState) {
        _state.value = transform(_state.value)
    }

    fun setCustomField(fieldId: String, value: String) {
        _state.value = _state.value.copy(customData = _state.value.customData + (fieldId to value))
    }

    fun setMember(id: String?, name: String) {
        _state.value = _state.value.copy(memberId = id, memberName = name)
    }

    fun save(forceSaveDuplicate: Boolean = false, onSaved: () -> Unit) {
        val s = _state.value
        val amountValue = s.amount.toDoubleOrNull()
        if (amountValue == null || amountValue <= 0.0) {
            _state.value = s.copy(errorMessage = "Enter a valid amount greater than zero.")
            return
        }
        if (s.category.isBlank()) {
            _state.value = s.copy(errorMessage = "Please choose a category.")
            return
        }

        viewModelScope.launch {
            val entity = TransactionEntity(
                id = s.id ?: Ids.next(),
                kind = s.kind,
                date = s.date,
                amount = amountValue,
                category = s.category,
                payMethod = s.payMethod,
                memberId = s.memberId,
                note = s.note,
                customDataJson = JsonCodec.encodeCustomData(s.customData)
            )

            if (!forceSaveDuplicate) {
                val dup = repository.findDuplicate(entity, s.id)
                if (dup != null) {
                    _state.value = s.copy(duplicateOf = dup)
                    return@launch
                }
            }

            repository.save(entity)
            _state.value = s.copy(saved = true, errorMessage = null, duplicateOf = null)
            onSaved()
        }
    }

    fun dismissDuplicateWarning() {
        _state.value = _state.value.copy(duplicateOf = null)
    }
}
