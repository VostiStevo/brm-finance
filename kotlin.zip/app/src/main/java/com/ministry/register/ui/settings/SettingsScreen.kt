package com.ministry.register.ui.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.ministry.register.ui.components.AppTextField
import com.ministry.register.ui.components.SectionDivider
import com.ministry.register.ui.components.SheetCard

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel,
    onManageFormSections: () -> Unit,
    onManageMemberFields: () -> Unit,
    onManageFinanceFields: () -> Unit,
    onManageSecurity: () -> Unit
) {
    val settings by viewModel.settings.collectAsState()

    var ministryName by remember(settings.ministryName) { mutableStateOf(settings.ministryName) }
    var churchName by remember(settings.churchName) { mutableStateOf(settings.churchName) }
    var currencySymbol by remember(settings.currencySymbol) { mutableStateOf(settings.currencySymbol) }
    var regPrefix by remember(settings.regNoPrefix) { mutableStateOf(settings.regNoPrefix) }
    var regDigits by remember(settings.regNoDigits) { mutableStateOf(settings.regNoDigits.toString()) }
    var renewalDays by remember(settings.renewalWarningDays) { mutableStateOf(settings.renewalWarningDays.toString()) }
    var incomeCats by remember(settings.incomeCategories) { mutableStateOf(settings.incomeCategories.joinToString("\n")) }
    var expenseCats by remember(settings.expenseCategories) { mutableStateOf(settings.expenseCategories.joinToString("\n")) }
    var payMethods by remember(settings.payMethods) { mutableStateOf(settings.payMethods.joinToString("\n")) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Settings") }) },
        bottomBar = {
            BottomAppBar {
                Button(
                    onClick = {
                        viewModel.updateGeneral(ministryName, churchName, currencySymbol)
                        viewModel.updateRegNo(regPrefix, regDigits.toIntOrNull() ?: 4)
                        viewModel.updateRenewalWarningDays(renewalDays.toIntOrNull() ?: 30)
                        viewModel.updateCategories(
                            incomeCats.lines().map { it.trim() }.filter { it.isNotBlank() },
                            expenseCats.lines().map { it.trim() }.filter { it.isNotBlank() },
                            payMethods.lines().map { it.trim() }.filter { it.isNotBlank() }
                        )
                    },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)
                ) { Text("Save Settings") }
            }
        }
    ) { padding ->
        LazyColumn(modifier = Modifier.padding(padding).fillMaxWidth().padding(14.dp)) {
            item {
                SectionDivider("General")
                SheetCard(modifier = Modifier.padding(bottom = 14.dp)) {
                    AppTextField("Ministry Name", ministryName, { ministryName = it }, modifier = Modifier.padding(bottom = 10.dp))
                    AppTextField("Church / App Subtitle", churchName, { churchName = it }, modifier = Modifier.padding(bottom = 10.dp))
                    AppTextField("Currency Symbol", currencySymbol, { currencySymbol = it }, modifier = Modifier.padding(bottom = 10.dp))
                    AppTextField("Membership Renewal Warning (days)", renewalDays, { renewalDays = it })
                }

                SectionDivider("Registration Number")
                SheetCard(modifier = Modifier.padding(bottom = 14.dp)) {
                    AppTextField("Prefix", regPrefix, { regPrefix = it }, placeholder = "REG-", modifier = Modifier.padding(bottom = 10.dp))
                    AppTextField("Digits", regDigits, { regDigits = it.filter { c -> c.isDigit() } })
                }

                SectionDivider("Categories")
                SheetCard(modifier = Modifier.padding(bottom = 14.dp)) {
                    AppTextField("Income Categories (one per line)", incomeCats, { incomeCats = it }, singleLine = false, modifier = Modifier.padding(bottom = 10.dp))
                    AppTextField("Expense Categories (one per line)", expenseCats, { expenseCats = it }, singleLine = false, modifier = Modifier.padding(bottom = 10.dp))
                    AppTextField("Payment Methods (one per line)", payMethods, { payMethods = it }, singleLine = false)
                }

                SectionDivider("Membership Form")
                SheetCard(modifier = Modifier.padding(bottom = 14.dp)) {
                    SettingsLinkRow("Form Sections", "Rename, add, or remove headers like Basic Details / Membership", onManageFormSections)
                    SettingsLinkRow("Custom Fields", "Add your own questions to the membership form", onManageMemberFields)
                }

                SectionDivider("Finance Form")
                SheetCard(modifier = Modifier.padding(bottom = 14.dp)) {
                    SettingsLinkRow("Custom Fields", "Add your own questions to the income/expense form", onManageFinanceFields)
                }

                SectionDivider("Security")
                SheetCard(modifier = Modifier.padding(bottom = 14.dp)) {
                    SettingsLinkRow(
                        if (settings.securityEnabled) "Change Password / Question" else "Set Up App Lock",
                        "Protect member and finance data with a password",
                        onManageSecurity
                    )
                }

                Text(
                    "All data is stored only on this device (nothing is sent online). Export or back up regularly, especially before updating or reinstalling the app.",
                    style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier.padding(bottom = 16.dp)
                )

                Spacer(Modifier.height(80.dp))
            }
        }
    }
}

@Composable
private fun SettingsLinkRow(title: String, subtitle: String, onClick: () -> Unit) {
    ListItem(
        headlineContent = { Text(title) },
        supportingContent = { Text(subtitle) },
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)
    )
    Divider()
}
