package com.ministry.register.ui.members

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.ministry.register.data.db.entity.FamilyMember
import com.ministry.register.data.settings.CustomFieldDef
import com.ministry.register.data.settings.FieldType
import com.ministry.register.data.settings.FormSection
import com.ministry.register.ui.components.AppDropdownField
import com.ministry.register.ui.components.AppTextField
import com.ministry.register.ui.components.SectionDivider
import com.ministry.register.ui.theme.ExpenseColor

private val GENDERS = listOf("Male", "Female")
private val MEMBERSHIP_TYPES = listOf("Regular", "Visitor", "Transferred Out", "Deceased")
private val FAMILY_RELATIONS = listOf("Spouse", "Child", "Parent", "Sibling", "Guardian", "Other")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MemberFormScreen(
    viewModel: MemberFormViewModel,
    onDone: () -> Unit,
    onBack: () -> Unit
) {
    val state by viewModel.state.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (state.id == null) "Add Member" else "Edit Member") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") }
                }
            )
        },
        bottomBar = {
            BottomAppBar {
                Button(
                    onClick = { viewModel.save(onSaved = onDone) },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)
                ) { Text("Save Member") }
            }
        }
    ) { padding ->
        if (state.isLoading) {
            Box(Modifier.fillMaxSize(), contentAlignment = androidx.compose.ui.Alignment.Center) { CircularProgressIndicator() }
            return@Scaffold
        }

        LazyColumn(modifier = Modifier.padding(padding).fillMaxWidth().padding(horizontal = 14.dp)) {
            item {
                if (state.errorMessage != null) {
                    Text(state.errorMessage!!, color = ExpenseColor, modifier = Modifier.padding(vertical = 8.dp))
                }
            }

            items(state.settings.memberFormSections, key = { it.id }) { section ->
                SectionBlock(section, state, viewModel)
            }

            if (state.settings.memberFormFields["family"] != false) {
                item {
                    SectionDivider("Family / Household")
                    state.familyMembers.forEachIndexed { index, fm ->
                        FamilyRow(fm, onChange = { viewModel.updateFamilyRow(index, it) }, onRemove = { viewModel.removeFamilyRow(index) })
                    }
                    TextButton(onClick = { viewModel.addFamilyRow() }) { Text("+ Add Family Member") }
                }
            }

            if (state.settings.memberFormFields["notes"] != false) {
                item {
                    SectionDivider("Notes")
                    AppTextField(
                        "Notes", state.notes, { viewModel.update { s -> s.copy(notes = it) } },
                        singleLine = false, modifier = Modifier.padding(bottom = 16.dp)
                    )
                }
            }

            item { Spacer(Modifier.height(80.dp)) }
        }
    }

    if (state.duplicateOf != null) {
        AlertDialog(
            onDismissRequest = { viewModel.dismissDuplicateWarning() },
            title = { Text("Possible duplicate") },
            text = { Text("A member named \"${state.duplicateOf?.name}\" with the same date of birth already exists. Save anyway?") },
            confirmButton = {
                TextButton(onClick = { viewModel.save(forceSaveDuplicate = true, onSaved = onDone) }) { Text("Save Anyway") }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.dismissDuplicateWarning() }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun SectionBlock(section: FormSection, state: MemberFormState, viewModel: MemberFormViewModel) {
    val sectionFields = state.settings.customFields.filter { (it.sectionId.ifBlank { "additional" }) == section.id }
    val hasCore = section.id == "basic" || section.id == "membership"
    if (!hasCore && sectionFields.isEmpty()) return

    SectionDivider(section.label)

    when (section.id) {
        "basic" -> {
            AppTextField("Full Name *", state.name, { viewModel.update { s -> s.copy(name = it.uppercase()) } }, modifier = Modifier.padding(bottom = 10.dp))
            Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                AppDropdownField("Gender *", GENDERS, state.gender, { it }, { viewModel.update { s -> s.copy(gender = it) } }, modifier = Modifier.weight(1f))
                AppTextField("Date of Birth *", state.dob, { viewModel.update { s -> s.copy(dob = it) } }, placeholder = "YYYY-MM-DD", modifier = Modifier.weight(1f))
            }
            Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                AppTextField("Age", state.age?.toString() ?: "", {}, readOnly = true, modifier = Modifier.weight(1f))
                AppTextField(
                    "Age Group",
                    com.ministry.register.data.util.AgeUtils.ageGroup(state.age, state.settings.ageGroupBoundaries),
                    {}, readOnly = true, modifier = Modifier.weight(1f)
                )
            }
            if (state.settings.memberFormFields["regNo"] != false) {
                AppTextField(
                    "Registration Number", state.regNo, { viewModel.update { s -> s.copy(regNo = it) } },
                    supportingText = "Auto-suggested from existing records — you can edit it if needed.",
                    modifier = Modifier.padding(bottom = 10.dp)
                )
            }
        }
        "membership" -> {
            if (state.settings.memberFormFields["membershipType"] != false) {
                AppDropdownField(
                    "Membership Type", MEMBERSHIP_TYPES, state.membershipType, { it },
                    { viewModel.update { s -> s.copy(membershipType = it) } },
                    modifier = Modifier.padding(bottom = 10.dp)
                )
            }
            if (state.settings.memberFormFields["joined"] != false) {
                AppTextField("Date Joined", state.joined, { viewModel.update { s -> s.copy(joined = it) } }, placeholder = "YYYY-MM-DD", modifier = Modifier.padding(bottom = 10.dp))
            }
            if (state.settings.memberFormFields["membershipType"] != false && state.membershipType == "Regular") {
                AppTextField(
                    "Membership Expiry / Renewal Date", state.membershipExpiry,
                    { viewModel.update { s -> s.copy(membershipExpiry = it) } }, placeholder = "YYYY-MM-DD",
                    modifier = Modifier.padding(bottom = 10.dp)
                )
            }
        }
    }

    sectionFields.forEach { def ->
        if (isVisible(def, state.customData)) {
            CustomFieldInput(def, state, viewModel)
        }
    }
}

private fun isVisible(def: CustomFieldDef, customData: Map<String, String>): Boolean {
    if (def.condField.isBlank()) return true
    return customData[def.condField] == def.condValue
}

@Composable
private fun CustomFieldInput(def: CustomFieldDef, state: MemberFormState, viewModel: MemberFormViewModel) {
    val value = state.customData[def.id] ?: ""
    val label = def.label + if (def.mandatory) " *" else ""

    when (def.type) {
        FieldType.LIST -> AppDropdownField(
            label, def.options, value.ifBlank { null }, { it },
            { viewModel.setCustomField(def.id, it) },
            modifier = Modifier.padding(bottom = 10.dp)
        )
        FieldType.REPEATING -> {
            SectionDivider(def.label)
            val rows = state.repeatingData[def.id] ?: emptyList()
            rows.forEachIndexed { index, row ->
                Row(Modifier.fillMaxWidth().padding(bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AppDropdownField("Type", def.options, row.type.ifBlank { null }, { it },
                        { viewModel.updateRepeatingRow(def.id, index, row.copy(type = it)) }, modifier = Modifier.weight(1f))
                    AppTextField(def.subLabel.ifBlank { "Value" }, row.value,
                        { viewModel.updateRepeatingRow(def.id, index, row.copy(value = it)) }, modifier = Modifier.weight(1f))
                    IconButton(onClick = { viewModel.removeRepeatingRow(def.id, index) }) {
                        Icon(Icons.Default.Close, contentDescription = "Remove")
                    }
                }
            }
            TextButton(onClick = { viewModel.addRepeatingRow(def.id) }) { Text("+ Add ${def.label}") }
        }
        else -> AppTextField(
            label, value, { viewModel.setCustomField(def.id, it) },
            placeholder = def.subLabel,
            modifier = Modifier.padding(bottom = 10.dp)
        )
    }
}

@Composable
private fun FamilyRow(member: FamilyMember, onChange: (FamilyMember) -> Unit, onRemove: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        AppTextField("Name", member.name, { onChange(member.copy(name = it)) }, modifier = Modifier.weight(2f))
        AppDropdownField("Relation", FAMILY_RELATIONS, member.relation, { it }, { onChange(member.copy(relation = it)) }, modifier = Modifier.weight(1.4f))
        IconButton(onClick = onRemove) { Icon(Icons.Default.Close, contentDescription = "Remove") }
    }
}
