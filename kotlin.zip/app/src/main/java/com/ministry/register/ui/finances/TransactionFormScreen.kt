package com.ministry.register.ui.finances

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.ministry.register.data.db.entity.TxnKind
import com.ministry.register.data.settings.CustomFieldDef
import com.ministry.register.data.settings.FieldType
import com.ministry.register.ui.components.AppDropdownField
import com.ministry.register.ui.components.AppTextField
import com.ministry.register.ui.components.SectionDivider
import com.ministry.register.ui.theme.ExpenseColor

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TransactionFormScreen(
    viewModel: TransactionFormViewModel,
    onDone: () -> Unit,
    onBack: () -> Unit
) {
    val state by viewModel.state.collectAsState()
    val kindLabel = if (state.kind == TxnKind.INCOME) "Income" else "Expense"

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (state.id == null) "Add $kindLabel" else "Edit $kindLabel") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") } }
            )
        },
        bottomBar = {
            BottomAppBar {
                Button(
                    onClick = { viewModel.save(onSaved = onDone) },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)
                ) { Text("Save $kindLabel") }
            }
        }
    ) { padding ->
        if (state.isLoading) {
            Box(Modifier.padding(padding).fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            return@Scaffold
        }

        val categories = if (state.kind == TxnKind.INCOME) state.settings.incomeCategories else state.settings.expenseCategories

        LazyColumn(modifier = Modifier.padding(padding).fillMaxWidth().padding(horizontal = 14.dp)) {
            item {
                if (state.errorMessage != null) {
                    Text(state.errorMessage!!, color = ExpenseColor, modifier = Modifier.padding(vertical = 8.dp))
                }

                SectionDivider("Details")
                AppTextField("Date", state.date, { viewModel.update { s -> s.copy(date = it) } }, placeholder = "YYYY-MM-DD", modifier = Modifier.padding(bottom = 10.dp))
                AppTextField("Amount *", state.amount, { viewModel.update { s -> s.copy(amount = it) } }, placeholder = "0.00", modifier = Modifier.padding(bottom = 10.dp))
                AppDropdownField("Category *", categories, state.category.ifBlank { null }, { it }, { viewModel.update { s -> s.copy(category = it) } }, modifier = Modifier.padding(bottom = 10.dp))

                if (state.settings.financeFormFields["payMethod"] != false) {
                    AppDropdownField(
                        "Payment Method", state.settings.payMethods, state.payMethod.ifBlank { null }, { it },
                        { viewModel.update { s -> s.copy(payMethod = it) } }, modifier = Modifier.padding(bottom = 10.dp)
                    )
                }

                if (state.settings.financeFormFields["member"] != false) {
                    AppDropdownField(
                        "Linked Member (optional)",
                        listOf<Pair<String, String>?>(null) + state.memberOptions,
                        state.memberOptions.firstOrNull { it.first == state.memberId },
                        { it?.second ?: "None" },
                        { viewModel.setMember(it?.first, it?.second ?: "") },
                        modifier = Modifier.padding(bottom = 10.dp)
                    )
                }

                state.settings.financeCustomFields.forEach { def ->
                    CustomFinanceFieldInput(def, state.customData) { id, v -> viewModel.setCustomField(id, v) }
                }

                if (state.settings.financeFormFields["note"] != false) {
                    AppTextField("Note", state.note, { viewModel.update { s -> s.copy(note = it) } }, singleLine = false, modifier = Modifier.padding(bottom = 10.dp))
                }

                Spacer(Modifier.height(80.dp))
            }
        }
    }

    if (state.duplicateOf != null) {
        AlertDialog(
            onDismissRequest = { viewModel.dismissDuplicateWarning() },
            title = { Text("Possible duplicate") },
            text = { Text("A ${kindLabel.lowercase()} record with the same date, amount, and category already exists. Save anyway?") },
            confirmButton = {
                TextButton(onClick = { viewModel.save(forceSaveDuplicate = true, onSaved = onDone) }) { Text("Save Anyway") }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.dismissDuplicateWarning() }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun CustomFinanceFieldInput(def: CustomFieldDef, customData: Map<String, String>, onChange: (String, String) -> Unit) {
    val value = customData[def.id] ?: ""
    val label = def.label + if (def.mandatory) " *" else ""
    when (def.type) {
        FieldType.LIST -> AppDropdownField(label, def.options, value.ifBlank { null }, { it }, { onChange(def.id, it) }, modifier = Modifier.padding(bottom = 10.dp))
        else -> AppTextField(label, value, { onChange(def.id, it) }, placeholder = def.subLabel, modifier = Modifier.padding(bottom = 10.dp))
    }
}
