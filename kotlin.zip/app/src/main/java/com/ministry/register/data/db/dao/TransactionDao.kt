package com.ministry.register.data.db.dao

import androidx.room.*
import com.ministry.register.data.db.entity.TransactionEntity
import com.ministry.register.data.db.entity.TxnKind
import kotlinx.coroutines.flow.Flow

@Dao
interface TransactionDao {

    @Query("SELECT * FROM transactions ORDER BY date DESC, createdAt DESC")
    fun observeAll(): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions ORDER BY date DESC, createdAt DESC")
    suspend fun getAll(): List<TransactionEntity>

    @Query("SELECT * FROM transactions WHERE kind = :kind ORDER BY date DESC, createdAt DESC")
    fun observeByKind(kind: TxnKind): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE id = :id")
    suspend fun getById(id: String): TransactionEntity?

    @Query("SELECT * FROM transactions WHERE date BETWEEN :start AND :end ORDER BY date ASC")
    suspend fun getBetween(start: String, end: String): List<TransactionEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(txn: TransactionEntity)

    @Delete
    suspend fun delete(txn: TransactionEntity)

    @Query("DELETE FROM transactions WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("DELETE FROM transactions WHERE id IN (:ids)")
    suspend fun deleteByIds(ids: List<String>)

    @Query("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE kind = :kind AND date LIKE :monthPrefix || '%'")
    suspend fun sumForMonth(kind: TxnKind, monthPrefix: String): Double

    @Query("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE kind = :kind")
    suspend fun sumAll(kind: TxnKind): Double
}
