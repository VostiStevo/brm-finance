package com.ministry.register.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val Ink = Color(0xFF152420)
val Page = Color(0xFFFAF6EA)
val Cover = Color(0xFF132420)
val Cover2 = Color(0xFF0D1A17)
val Gold = Color(0xFFC6A15B)
val GoldDim = Color(0xFF9C7F42)
val IncomeColor = Color(0xFF3F7350)
val ExpenseColor = Color(0xFF8B3A3A)
val LineColor = Color(0xFFD8CFB2)
val MutedColor = Color(0xFF6B6250)
val WarnColor = Color(0xFFA9752B)
val UrgentColor = Color(0xFFB23B3B)

private val AppColorScheme = lightColorScheme(
    primary = Gold,
    onPrimary = Cover2,
    secondary = Cover,
    onSecondary = Page,
    background = Page,
    onBackground = Ink,
    surface = Page,
    onSurface = Ink,
    error = ExpenseColor
)

private val AppTypography = Typography(
    titleLarge = TextStyle(fontWeight = FontWeight.Bold, fontSize = 19.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 16.sp),
    bodyLarge = TextStyle(fontSize = 15.sp),
    bodyMedium = TextStyle(fontSize = 13.5.sp),
    labelSmall = TextStyle(fontSize = 11.sp, color = MutedColor)
)

@Composable
fun MinistryRegisterTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AppColorScheme,
        typography = AppTypography,
        content = content
    )
}
