package com.ministry.register.data.db.dao

import androidx.room.*
import com.ministry.register.data.db.entity.MemberEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface MemberDao {

    @Query("SELECT * FROM members ORDER BY name ASC")
    fun observeAll(): Flow<List<MemberEntity>>

    @Query("SELECT * FROM members ORDER BY name ASC")
    suspend fun getAll(): List<MemberEntity>

    @Query("SELECT * FROM members WHERE id = :id")
    suspend fun getById(id: String): MemberEntity?

    @Query("SELECT regNo FROM members")
    suspend fun getAllRegNos(): List<String>

    @Query(
        """SELECT * FROM members WHERE
           name LIKE '%' || :query || '%' OR
           gender LIKE '%' || :query || '%' OR
           regNo LIKE '%' || :query || '%'
           ORDER BY name ASC"""
    )
    fun search(query: String): Flow<List<MemberEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(member: MemberEntity)

    @Delete
    suspend fun delete(member: MemberEntity)

    @Query("DELETE FROM members WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("DELETE FROM members WHERE id IN (:ids)")
    suspend fun deleteByIds(ids: List<String>)

    @Query("SELECT COUNT(*) FROM members")
    fun observeCount(): Flow<Int>
}
