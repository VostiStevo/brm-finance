package com.ministry.register.data

import kotlin.random.Random

/** Generates a short, sufficiently-unique id — time-based prefix + random suffix. */
object Ids {
    fun next(): String {
        val time = System.currentTimeMillis().toString(36)
        val rand = (1..5).joinToString("") { "0123456789abcdefghijklmnopqrstuvwxyz".random(Random).toString() }
        return time + rand
    }
}
