package com.ministry.register.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.ministry.register.MinistryApp
import com.ministry.register.data.db.entity.TxnKind
import com.ministry.register.ui.dashboard.DashboardScreen
import com.ministry.register.ui.dashboard.DashboardViewModel
import com.ministry.register.ui.finances.*
import com.ministry.register.ui.lock.LockScreen
import com.ministry.register.ui.lock.LockViewModel
import com.ministry.register.ui.members.*
import com.ministry.register.ui.reports.ReportsScreen
import com.ministry.register.ui.reports.ReportsViewModel
import com.ministry.register.ui.settings.*

private data class TabItem(val route: String, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

private val TABS = listOf(
    TabItem(Routes.DASHBOARD, "Dashboard", Icons.Default.Home),
    TabItem(Routes.MEMBERS, "Members", Icons.Default.People),
    TabItem(Routes.FINANCES, "Finances", Icons.Default.AccountBalanceWallet),
    TabItem(Routes.REPORTS, "Reports", Icons.Default.Description),
    TabItem(Routes.SETTINGS, "Settings", Icons.Default.Settings)
)

@Composable
fun AppRoot() {
    var unlocked by remember { mutableStateOf(false) }
    val app = LocalContext.current.applicationContext as MinistryApp

    if (!unlocked) {
        val lockViewModel: LockViewModel = viewModel(factory = viewModelFactory {
            initializer { LockViewModel(app.securityManager, app.settingsRepository) }
        })
        LockScreen(lockViewModel, onUnlocked = { unlocked = true })
        return
    }

    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    Scaffold(
        bottomBar = {
            if (TABS.any { it.route == currentRoute }) {
                NavigationBar {
                    TABS.forEach { tab ->
                        NavigationBarItem(
                            selected = currentRoute == tab.route,
                            onClick = {
                                navController.navigate(tab.route) {
                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(tab.icon, contentDescription = tab.label) },
                            label = { Text(tab.label) }
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Routes.DASHBOARD,
            modifier = androidx.compose.ui.Modifier.padding(padding)
        ) {
            composable(Routes.DASHBOARD) {
                val vm: DashboardViewModel = viewModel(factory = viewModelFactory {
                    initializer { DashboardViewModel(app.memberRepository, app.transactionRepository, app.settingsRepository) }
                })
                DashboardScreen(vm)
            }

            composable(Routes.MEMBERS) {
                val vm: MembersViewModel = viewModel(factory = viewModelFactory {
                    initializer { MembersViewModel(app.memberRepository, app.settingsRepository) }
                })
                MembersListScreen(
                    viewModel = vm,
                    onAddMember = { navController.navigate(Routes.memberForm()) },
                    onOpenMember = { id -> navController.navigate(Routes.memberDetail(id)) }
                )
            }

            composable(
                Routes.MEMBER_DETAIL,
                arguments = listOf(navArgument("id") { type = NavType.StringType })
            ) { backStack ->
                val id = backStack.arguments?.getString("id")!!
                val vm: MemberDetailViewModel = viewModel(factory = viewModelFactory {
                    initializer { MemberDetailViewModel(app.memberRepository, app.settingsRepository, id) }
                })
                MemberDetailScreen(
                    viewModel = vm,
                    onBack = { navController.popBackStack() },
                    onEdit = { navController.navigate(Routes.memberForm(it)) },
                    onDeleted = { navController.popBackStack() }
                )
            }

            composable(
                Routes.MEMBER_FORM,
                arguments = listOf(navArgument("id") { type = NavType.StringType; nullable = true; defaultValue = null })
            ) { backStack ->
                val id = backStack.arguments?.getString("id")
                val vm: MemberFormViewModel = viewModel(factory = viewModelFactory {
                    initializer { MemberFormViewModel(app.memberRepository, app.settingsRepository, id) }
                })
                MemberFormScreen(
                    viewModel = vm,
                    onDone = { navController.popBackStack() },
                    onBack = { navController.popBackStack() }
                )
            }

            composable(Routes.FINANCES) {
                val vm: FinancesViewModel = viewModel(factory = viewModelFactory {
                    initializer { FinancesViewModel(app.transactionRepository, app.settingsRepository) }
                })
                FinancesListScreen(
                    viewModel = vm,
                    onAddTransaction = { kind -> navController.navigate(Routes.txnForm(kind.name)) },
                    onOpenTransaction = { kind, id -> navController.navigate(Routes.txnForm(kind.name, id)) }
                )
            }

            composable(
                Routes.TXN_FORM,
                arguments = listOf(
                    navArgument("kind") { type = NavType.StringType },
                    navArgument("id") { type = NavType.StringType; nullable = true; defaultValue = null }
                )
            ) { backStack ->
                val kind = TxnKind.valueOf(backStack.arguments?.getString("kind") ?: TxnKind.INCOME.name)
                val id = backStack.arguments?.getString("id")
                val vm: TransactionFormViewModel = viewModel(factory = viewModelFactory {
                    initializer { TransactionFormViewModel(app.transactionRepository, app.memberRepository, app.settingsRepository, kind, id) }
                })
                TransactionFormScreen(
                    viewModel = vm,
                    onDone = { navController.popBackStack() },
                    onBack = { navController.popBackStack() }
                )
            }

            composable(Routes.REPORTS) {
                val vm: ReportsViewModel = viewModel(factory = viewModelFactory {
                    initializer {
                        ReportsViewModel(app, app.memberRepository, app.transactionRepository, app.settingsRepository, app.pdfReportGenerator, app.backupManager)
                    }
                })
                ReportsScreen(vm)
            }

            composable(Routes.SETTINGS) {
                val vm: SettingsViewModel = settingsViewModel(app)
                SettingsScreen(
                    viewModel = vm,
                    onManageFormSections = { navController.navigate(Routes.FORM_SECTIONS) },
                    onManageMemberFields = { navController.navigate(Routes.customFields("member")) },
                    onManageFinanceFields = { navController.navigate(Routes.customFields("finance")) },
                    onManageSecurity = { navController.navigate(Routes.SECURITY_SETTINGS) }
                )
            }

            composable(Routes.FORM_SECTIONS) {
                val vm: SettingsViewModel = settingsViewModel(app)
                FormSectionsScreen(vm, onBack = { navController.popBackStack() })
            }

            composable(
                Routes.CUSTOM_FIELDS,
                arguments = listOf(navArgument("scope") { type = NavType.StringType })
            ) { backStack ->
                val scope = backStack.arguments?.getString("scope") ?: "member"
                val vm: SettingsViewModel = settingsViewModel(app)
                CustomFieldsListScreen(
                    viewModel = vm,
                    scope = scope,
                    onBack = { navController.popBackStack() },
                    onAdd = { navController.navigate(Routes.customFieldEditor(scope)) },
                    onEdit = { id -> navController.navigate(Routes.customFieldEditor(scope, id)) }
                )
            }

            composable(
                Routes.CUSTOM_FIELD_EDITOR,
                arguments = listOf(
                    navArgument("scope") { type = NavType.StringType },
                    navArgument("id") { type = NavType.StringType; nullable = true; defaultValue = null }
                )
            ) { backStack ->
                val scope = backStack.arguments?.getString("scope") ?: "member"
                val id = backStack.arguments?.getString("id")
                val vm: SettingsViewModel = settingsViewModel(app)
                CustomFieldEditorScreen(
                    viewModel = vm,
                    scope = scope,
                    fieldId = id,
                    onDone = { navController.popBackStack() },
                    onBack = { navController.popBackStack() }
                )
            }

            composable(Routes.SECURITY_SETTINGS) {
                val vm: SettingsViewModel = settingsViewModel(app)
                SecuritySettingsScreen(
                    viewModel = vm,
                    onBack = { navController.popBackStack() },
                    onDisabled = { navController.popBackStack() }
                )
            }
        }
    }
}

@Composable
private fun settingsViewModel(app: MinistryApp): SettingsViewModel = viewModel(factory = viewModelFactory {
    initializer { SettingsViewModel(app.settingsRepository, app.securityManager) }
})
