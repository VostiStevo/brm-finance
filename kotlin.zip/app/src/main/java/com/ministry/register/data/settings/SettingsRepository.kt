package com.ministry.register.data.settings

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.serialization.json.Json

private val Context.dataStore by preferencesDataStore(name = "app_settings")
private val SETTINGS_KEY = stringPreferencesKey("settings_json")

/**
 * Holds the single AppSettings blob, the same way the web app kept one
 * `settings` object in localStorage. Reactive via Flow so every screen
 * that reads settings recomposes automatically when they change.
 */
class SettingsRepository(private val context: Context) {

    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    private fun decode(raw: String?): AppSettings {
        if (raw.isNullOrBlank()) return AppSettings()
        return runCatching { json.decodeFromString(AppSettings.serializer(), raw) }.getOrDefault(AppSettings())
    }

    val settingsFlow: Flow<AppSettings> = context.dataStore.data.map { prefs -> decode(prefs[SETTINGS_KEY]) }

    /** One-shot read, useful from non-Compose contexts like export/report generation. */
    suspend fun current(): AppSettings = decode(context.dataStore.data.first()[SETTINGS_KEY])

    suspend fun update(transform: (AppSettings) -> AppSettings) {
        context.dataStore.edit { prefs ->
            val updated = transform(decode(prefs[SETTINGS_KEY]))
            prefs[SETTINGS_KEY] = json.encodeToString(AppSettings.serializer(), updated)
        }
    }

    suspend fun replace(settings: AppSettings) {
        context.dataStore.edit { prefs ->
            prefs[SETTINGS_KEY] = json.encodeToString(AppSettings.serializer(), settings)
        }
    }
}
