package com.ministry.register.ui.finances

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ministry.register.data.db.entity.TransactionEntity
import com.ministry.register.data.db.entity.TxnKind
import com.ministry.register.data.repository.TransactionRepository
import com.ministry.register.data.settings.AppSettings
import com.ministry.register.data.settings.SettingsRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class FinancesUiState(
    val kind: TxnKind = TxnKind.INCOME,
    val transactions: List<TransactionEntity> = emptyList(),
    val settings: AppSettings = AppSettings(),
    val selectMode: Boolean = false,
    val selectedIds: Set<String> = emptySet(),
    val total: Double = 0.0
)

class FinancesViewModel(
    private val repository: TransactionRepository,
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    private val kind = MutableStateFlow(TxnKind.INCOME)
    private val selectMode = MutableStateFlow(false)
    private val selectedIds = MutableStateFlow<Set<String>>(emptySet())

    val state: StateFlow<FinancesUiState> = combine(
        kind.flatMapLatest { repository.observeByKind(it) },
        kind, settingsRepository.settingsFlow, selectMode, selectedIds
    ) { txns, k, settings, select, selected ->
        FinancesUiState(k, txns, settings, select, selected, txns.sumOf { it.amount })
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), FinancesUiState())

    fun setKind(k: TxnKind) { kind.value = k; selectMode.value = false; selectedIds.value = emptySet() }
    fun toggleSelectMode() { selectMode.value = !selectMode.value; if (!selectMode.value) selectedIds.value = emptySet() }
    fun toggleSelect(id: String) {
        selectedIds.value = if (id in selectedIds.value) selectedIds.value - id else selectedIds.value + id
    }

    fun deleteSelected(onDone: () -> Unit) {
        viewModelScope.launch {
            repository.deleteMany(selectedIds.value.toList())
            selectedIds.value = emptySet()
            selectMode.value = false
            onDone()
        }
    }

    fun deleteOne(id: String, onDone: () -> Unit) {
        viewModelScope.launch { repository.delete(id); onDone() }
    }
}
