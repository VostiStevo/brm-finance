package com.ministry.register.data.util

import android.content.Context
import com.ministry.register.data.db.entity.MemberEntity
import com.ministry.register.data.db.entity.TransactionEntity
import com.ministry.register.data.repository.MemberRepository
import com.ministry.register.data.repository.TransactionRepository
import com.ministry.register.data.settings.AppSettings
import com.ministry.register.data.settings.SettingsRepository
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.io.File

@Serializable
data class BackupPayload(
    val exportedAt: Long = System.currentTimeMillis(),
    val settings: AppSettings,
    val members: List<MemberEntity>,
    val transactions: List<TransactionEntity>
)

enum class RestoreMode { REPLACE_ALL, MERGE_KEEP_EXISTING, MERGE_OVERWRITE_EXISTING }

class BackupManager(
    private val context: Context,
    private val memberRepository: MemberRepository,
    private val transactionRepository: TransactionRepository,
    private val settingsRepository: SettingsRepository
) {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true; prettyPrint = true }

    suspend fun exportBackup(): File {
        val payload = BackupPayload(
            settings = settingsRepository.current(),
            members = memberRepository.getAll(),
            transactions = transactionRepository.getAll()
        )
        val outDir = File(context.cacheDir, "backups").apply { mkdirs() }
        val outFile = File(outDir, "ministry_backup_${System.currentTimeMillis()}.json")
        outFile.writeText(json.encodeToString(BackupPayload.serializer(), payload))
        return outFile
    }

    fun readBackup(file: File): BackupPayload =
        json.decodeFromString(BackupPayload.serializer(), file.readText())

    suspend fun restore(payload: BackupPayload, mode: RestoreMode) {
        when (mode) {
            RestoreMode.REPLACE_ALL -> {
                val existingMembers = memberRepository.getAll().map { it.id }
                val existingTxns = transactionRepository.getAll().map { it.id }
                if (existingMembers.isNotEmpty()) memberRepository.deleteMany(existingMembers)
                if (existingTxns.isNotEmpty()) transactionRepository.deleteMany(existingTxns)
                payload.members.forEach { memberRepository.save(it) }
                payload.transactions.forEach { transactionRepository.save(it) }
                settingsRepository.replace(payload.settings)
            }
            RestoreMode.MERGE_KEEP_EXISTING -> {
                val existingMemberIds = memberRepository.getAll().map { it.id }.toSet()
                val existingTxnIds = transactionRepository.getAll().map { it.id }.toSet()
                payload.members.filter { it.id !in existingMemberIds }.forEach { memberRepository.save(it) }
                payload.transactions.filter { it.id !in existingTxnIds }.forEach { transactionRepository.save(it) }
            }
            RestoreMode.MERGE_OVERWRITE_EXISTING -> {
                payload.members.forEach { memberRepository.save(it) }
                payload.transactions.forEach { transactionRepository.save(it) }
            }
        }
    }
}
