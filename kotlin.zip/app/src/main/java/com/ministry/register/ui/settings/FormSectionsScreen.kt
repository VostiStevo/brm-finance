package com.ministry.register.ui.settings

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.ministry.register.data.settings.FormSection
import com.ministry.register.ui.components.AppTextField
import com.ministry.register.ui.components.ConfirmDialog

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FormSectionsScreen(viewModel: SettingsViewModel, onBack: () -> Unit) {
    val settings by viewModel.settings.collectAsState()
    var editingSection by remember { mutableStateOf<FormSection?>(null) }
    var showAddDialog by remember { mutableStateOf(false) }
    var confirmDeleteId by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Membership Form Sections") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") } }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAddDialog = true }) { Text("+") }
        }
    ) { padding ->
        LazyColumnSections(padding, settings.memberFormSections, viewModel,
            onEdit = { editingSection = it },
            onDelete = { confirmDeleteId = it.id }
        )
    }

    if (showAddDialog) {
        SectionEditDialog(
            title = "Add Header",
            initial = "",
            onDismiss = { showAddDialog = false },
            onSave = { label -> viewModel.addSection(label); showAddDialog = false }
        )
    }

    editingSection?.let { section ->
        SectionEditDialog(
            title = "Edit Header",
            initial = section.label,
            onDismiss = { editingSection = null },
            onSave = { label -> viewModel.renameSection(section.id, label); editingSection = null }
        )
    }

    confirmDeleteId?.let { id ->
        ConfirmDialog(
            message = "Delete this header? Any custom fields under it will move to another section.",
            onConfirm = { viewModel.deleteSection(id); confirmDeleteId = null },
            onDismiss = { confirmDeleteId = null }
        )
    }
}

@Composable
private fun LazyColumnSections(
    padding: androidx.compose.foundation.layout.PaddingValues,
    sections: List<FormSection>,
    viewModel: SettingsViewModel,
    onEdit: (FormSection) -> Unit,
    onDelete: (FormSection) -> Unit
) {
    androidx.compose.foundation.lazy.LazyColumn(modifier = Modifier.padding(padding).fillMaxWidth()) {
        androidx.compose.foundation.lazy.items(sections, key = { it.id }) { section ->
            val index = sections.indexOf(section)
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(Modifier.weight(1f)) {
                    Text(section.label, style = MaterialTheme.typography.bodyLarge)
                    if (section.core) Text("Built-in section", style = MaterialTheme.typography.labelSmall)
                }
                Row {
                    IconButton(onClick = { viewModel.moveSection(section.id, -1) }, enabled = index > 0) {
                        Icon(Icons.Default.ArrowUpward, contentDescription = "Move up")
                    }
                    IconButton(onClick = { viewModel.moveSection(section.id, 1) }, enabled = index < sections.size - 1) {
                        Icon(Icons.Default.ArrowDownward, contentDescription = "Move down")
                    }
                    IconButton(onClick = { onEdit(section) }) { Icon(Icons.Default.Edit, contentDescription = "Edit") }
                    if (!section.core) {
                        IconButton(onClick = { onDelete(section) }) { Icon(Icons.Default.Delete, contentDescription = "Delete") }
                    }
                }
            }
            Divider()
        }
    }
}

@Composable
private fun SectionEditDialog(title: String, initial: String, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var label by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { AppTextField("Header Label", label, { label = it }, placeholder = "e.g. Contact Information") },
        confirmButton = { TextButton(onClick = { if (label.isNotBlank()) onSave(label.trim()) }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
