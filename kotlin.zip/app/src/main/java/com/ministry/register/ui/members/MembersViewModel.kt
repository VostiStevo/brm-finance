package com.ministry.register.ui.members

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ministry.register.data.db.entity.MemberEntity
import com.ministry.register.data.repository.MemberRepository
import com.ministry.register.data.settings.AppSettings
import com.ministry.register.data.settings.SettingsRepository
import com.ministry.register.data.util.AgeUtils
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class MembersListUiState(
    val members: List<MemberEntity> = emptyList(),
    val settings: AppSettings = AppSettings(),
    val query: String = "",
    val selectMode: Boolean = false,
    val selectedIds: Set<String> = emptySet()
)

class MembersViewModel(
    private val repository: MemberRepository,
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    private val query = MutableStateFlow("")
    private val selectMode = MutableStateFlow(false)
    private val selectedIds = MutableStateFlow<Set<String>>(emptySet())

    val state: StateFlow<MembersListUiState> = combine(
        repository.observeAll(), settingsRepository.settingsFlow, query, selectMode, selectedIds
    ) { members, settings, q, select, selected ->
        val filtered = if (q.isBlank()) members else members.filter {
            it.name.contains(q, ignoreCase = true) || it.regNo.contains(q, ignoreCase = true) || it.gender.contains(q, ignoreCase = true)
        }
        MembersListUiState(filtered, settings, q, select, selected)
    }.stateIn(viewModelScope, kotlinx.coroutines.flow.SharingStarted.WhileSubscribed(5000), MembersListUiState())

    fun setQuery(q: String) { query.value = q }
    fun toggleSelectMode() { selectMode.value = !selectMode.value; if (!selectMode.value) selectedIds.value = emptySet() }
    fun toggleSelect(id: String) {
        selectedIds.value = if (id in selectedIds.value) selectedIds.value - id else selectedIds.value + id
    }
    fun selectAll(ids: List<String>) { selectedIds.value = ids.toSet() }

    fun deleteSelected(onDone: () -> Unit) {
        viewModelScope.launch {
            repository.deleteMany(selectedIds.value.toList())
            selectedIds.value = emptySet()
            selectMode.value = false
            onDone()
        }
    }

    fun deleteOne(id: String, onDone: () -> Unit) {
        viewModelScope.launch { repository.delete(id); onDone() }
    }
}

/** Small helper shared by list/detail for showing renewal urgency. */
object MembershipStatus {
    fun label(member: MemberEntity, warningDays: Int): Pair<String, androidx.compose.ui.graphics.Color> {
        if (member.membershipType != "Regular" || member.membershipExpiry.isBlank()) {
            return "Active" to com.ministry.register.ui.theme.IncomeColor
        }
        val days = AgeUtils.daysUntil(member.membershipExpiry) ?: return "—" to com.ministry.register.ui.theme.MutedColor
        return when {
            days < 0 -> "Expired" to com.ministry.register.ui.theme.ExpenseColor
            days <= warningDays -> "Renewal due" to com.ministry.register.ui.theme.WarnColor
            else -> "Active" to com.ministry.register.ui.theme.IncomeColor
        }
    }
}
