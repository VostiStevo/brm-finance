package com.ministry.register.ui

object Routes {
    const val LOCK = "lock"
    const val DASHBOARD = "dashboard"
    const val MEMBERS = "members"
    const val MEMBER_DETAIL = "member_detail/{id}"
    const val MEMBER_FORM = "member_form?id={id}"
    const val FINANCES = "finances"
    const val TXN_FORM = "txn_form/{kind}?id={id}"
    const val REPORTS = "reports"
    const val SETTINGS = "settings"
    const val FORM_SECTIONS = "form_sections"
    const val CUSTOM_FIELDS = "custom_fields/{scope}"
    const val CUSTOM_FIELD_EDITOR = "custom_field_editor/{scope}?id={id}"
    const val SECURITY_SETTINGS = "security_settings"

    fun memberDetail(id: String) = "member_detail/$id"
    fun memberForm(id: String? = null) = if (id != null) "member_form?id=$id" else "member_form"
    fun txnForm(kind: String, id: String? = null) = if (id != null) "txn_form/$kind?id=$id" else "txn_form/$kind"
    fun customFields(scope: String) = "custom_fields/$scope"
    fun customFieldEditor(scope: String, id: String? = null) =
        if (id != null) "custom_field_editor/$scope?id=$id" else "custom_field_editor/$scope"
}
