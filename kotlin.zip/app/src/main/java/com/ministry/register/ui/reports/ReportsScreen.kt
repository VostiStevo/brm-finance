package com.ministry.register.ui.reports

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.ministry.register.data.util.RestoreMode
import com.ministry.register.ui.components.SectionDivider
import com.ministry.register.ui.components.SheetCard
import java.io.File

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(viewModel: ReportsViewModel) {
    val state by viewModel.state.collectAsState()
    val context = LocalContext.current
    var showRestoreDialog by remember { mutableStateOf(false) }
    var pendingRestoreFile by remember { mutableStateOf<File?>(null) }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val temp = File(context.cacheDir, "restore_import.json")
            context.contentResolver.openInputStream(uri)?.use { input -> temp.outputStream().use { input.copyTo(it) } }
            pendingRestoreFile = temp
            showRestoreDialog = true
        }
    }

    LaunchedEffect(state.lastExportedFile) {
        state.lastExportedFile?.let { file -> shareFile(context, file) }
    }

    Scaffold(topBar = { TopAppBar(title = { Text("Reports") }) }) { padding ->
        LazyColumn(modifier = Modifier.padding(padding).fillMaxWidth().padding(14.dp)) {
            item {
                SheetCard(modifier = Modifier.padding(bottom = 14.dp)) {
                    Text("${state.memberCount} members · ${state.transactionCount} finance records on this device.")
                }

                SectionDivider("Member Records")
                SheetCard(modifier = Modifier.padding(bottom = 14.dp)) {
                    Button(onClick = { viewModel.exportMembersPdf() }, modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp), enabled = !state.isBusy) {
                        Text("Export as PDF")
                    }
                    OutlinedButton(onClick = { viewModel.exportMembersCsv() }, modifier = Modifier.fillMaxWidth(), enabled = !state.isBusy) {
                        Text("Export as CSV (Excel)")
                    }
                }

                SectionDivider("Finance Ledger")
                SheetCard(modifier = Modifier.padding(bottom = 14.dp)) {
                    Button(onClick = { viewModel.exportLedgerPdf() }, modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp), enabled = !state.isBusy) {
                        Text("Export as PDF")
                    }
                    OutlinedButton(onClick = { viewModel.exportLedgerCsv() }, modifier = Modifier.fillMaxWidth(), enabled = !state.isBusy) {
                        Text("Export as CSV (Excel)")
                    }
                }

                SectionDivider("Backup & Restore")
                SheetCard(modifier = Modifier.padding(bottom = 14.dp)) {
                    Text("A full backup includes all members, finance records, and settings.", modifier = Modifier.padding(bottom = 10.dp))
                    Button(onClick = { viewModel.exportFullBackup() }, modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp), enabled = !state.isBusy) {
                        Text("Export Full Backup (JSON)")
                    }
                    OutlinedButton(onClick = { filePicker.launch("application/json") }, modifier = Modifier.fillMaxWidth(), enabled = !state.isBusy) {
                        Text("Restore from Backup File")
                    }
                }

                if (state.isBusy) {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
                }
                state.message?.let {
                    Text(it, modifier = Modifier.padding(top = 8.dp))
                }

                Spacer(Modifier.height(80.dp))
            }
        }
    }

    if (showRestoreDialog && pendingRestoreFile != null) {
        AlertDialog(
            onDismissRequest = { showRestoreDialog = false },
            title = { Text("Restore Backup") },
            text = { Text("Replace all current data with this backup? This cannot be undone. Choose \"Merge\" instead to keep existing records and only add new ones.") },
            confirmButton = {
                TextButton(onClick = {
                    showRestoreDialog = false
                    viewModel.restoreBackup(pendingRestoreFile!!, RestoreMode.REPLACE_ALL)
                }) { Text("Replace All") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = {
                        showRestoreDialog = false
                        viewModel.restoreBackup(pendingRestoreFile!!, RestoreMode.MERGE_KEEP_EXISTING)
                    }) { Text("Merge") }
                    TextButton(onClick = { showRestoreDialog = false }) { Text("Cancel") }
                }
            }
        )
    }
}

private fun shareFile(context: android.content.Context, file: File) {
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = context.contentResolver.getType(uri) ?: "*/*"
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(intent, "Share report"))
}
