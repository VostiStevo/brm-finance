package com.ministry.register.ui.lock

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ministry.register.data.security.AttemptStatus
import com.ministry.register.data.security.SecurityManager
import com.ministry.register.data.settings.SettingsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class LockStage { LOADING, SETUP, LOGIN, FORGOT_QUESTION, UNLOCKED }

data class LockUiState(
    val stage: LockStage = LockStage.LOADING,
    val ministryName: String = "",
    val securityQuestion: String = "",
    val attempts: AttemptStatus = AttemptStatus(remaining = 5, lockedUntil = null),
    val errorMessage: String? = null
)

class LockViewModel(
    private val securityManager: SecurityManager,
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    private val _state = MutableStateFlow(LockUiState())
    val state: StateFlow<LockUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            val settings = settingsRepository.current()
            val attempts = securityManager.attemptStatus()
            _state.value = _state.value.copy(
                ministryName = settings.ministryName,
                securityQuestion = settings.securityQuestion,
                attempts = attempts,
                stage = if (!settings.securityEnabled) LockStage.SETUP else LockStage.LOGIN
            )
        }
    }

    fun submitSetup(password: String, question: String, answer: String) {
        if (password.length < 4) {
            _state.value = _state.value.copy(errorMessage = "Password must be at least 4 characters.")
            return
        }
        if (question.isBlank() || answer.isBlank()) {
            _state.value = _state.value.copy(errorMessage = "Please add a recovery question and answer.")
            return
        }
        viewModelScope.launch {
            securityManager.setUpPassword(password, question, answer)
            _state.value = _state.value.copy(stage = LockStage.UNLOCKED, errorMessage = null)
        }
    }

    fun submitLogin(password: String) {
        val locked = _state.value.attempts.lockedUntil
        if (locked != null && locked > System.currentTimeMillis()) {
            _state.value = _state.value.copy(errorMessage = "Too many attempts. Try again later.")
            return
        }
        viewModelScope.launch {
            if (securityManager.verifyPassword(password)) {
                securityManager.clearAttempts()
                _state.value = _state.value.copy(stage = LockStage.UNLOCKED, errorMessage = null)
            } else {
                val status = securityManager.recordFailedAttempt()
                _state.value = _state.value.copy(
                    attempts = status,
                    errorMessage = if (status.lockedUntil != null) "Too many failed attempts. Locked temporarily."
                    else "Incorrect password. ${status.remaining} attempt(s) left."
                )
            }
        }
    }

    fun goToForgotPassword() {
        _state.value = _state.value.copy(stage = LockStage.FORGOT_QUESTION, errorMessage = null)
    }

    fun backToLogin() {
        _state.value = _state.value.copy(stage = LockStage.LOGIN, errorMessage = null)
    }

    fun submitRecoveryAnswer(answer: String, newPassword: String) {
        if (newPassword.length < 4) {
            _state.value = _state.value.copy(errorMessage = "New password must be at least 4 characters.")
            return
        }
        viewModelScope.launch {
            if (securityManager.verifyAnswer(answer)) {
                securityManager.changePassword(newPassword)
                securityManager.clearAttempts()
                _state.value = _state.value.copy(stage = LockStage.LOGIN, errorMessage = "Password reset — please log in.")
            } else {
                _state.value = _state.value.copy(errorMessage = "That answer doesn't match our records.")
            }
        }
    }
}
