package com.ministry.register.data.repository

import com.ministry.register.data.db.dao.TransactionDao
import com.ministry.register.data.db.entity.TransactionEntity
import com.ministry.register.data.db.entity.TxnKind
import com.ministry.register.data.util.DuplicateDetector
import kotlinx.coroutines.flow.Flow

class TransactionRepository(private val dao: TransactionDao) {

    fun observeAll(): Flow<List<TransactionEntity>> = dao.observeAll()
    fun observeByKind(kind: TxnKind): Flow<List<TransactionEntity>> = dao.observeByKind(kind)

    suspend fun getById(id: String): TransactionEntity? = dao.getById(id)
    suspend fun getAll(): List<TransactionEntity> = dao.getAll()
    suspend fun getBetween(startIso: String, endIso: String): List<TransactionEntity> = dao.getBetween(startIso, endIso)

    suspend fun sumForMonth(kind: TxnKind, monthPrefix: String): Double = dao.sumForMonth(kind, monthPrefix)
    suspend fun sumAll(kind: TxnKind): Double = dao.sumAll(kind)

    suspend fun findDuplicate(candidate: TransactionEntity, excludeId: String?): TransactionEntity? =
        DuplicateDetector.findTransactionDuplicate(candidate, dao.getAll(), excludeId)

    suspend fun save(txn: TransactionEntity) = dao.upsert(txn)
    suspend fun delete(id: String) = dao.deleteById(id)
    suspend fun deleteMany(ids: List<String>) = dao.deleteByIds(ids)
}
