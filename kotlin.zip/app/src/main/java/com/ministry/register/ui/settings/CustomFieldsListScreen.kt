package com.ministry.register.ui.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.ministry.register.data.settings.CustomFieldDef
import com.ministry.register.ui.components.EmptyState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomFieldsListScreen(
    viewModel: SettingsViewModel,
    scope: String, // "member" or "finance"
    onBack: () -> Unit,
    onAdd: () -> Unit,
    onEdit: (String) -> Unit
) {
    val settings by viewModel.settings.collectAsState()
    val fields = if (scope == "finance") settings.financeCustomFields else settings.customFields
    val sections = settings.memberFormSections

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (scope == "finance") "Finance Custom Fields" else "Member Custom Fields") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") } }
            )
        },
        floatingActionButton = { FloatingActionButton(onClick = onAdd) { Text("+") } }
    ) { padding ->
        if (fields.isEmpty()) {
            Box(Modifier.padding(padding).fillMaxSize()) { EmptyState("No custom fields added yet.") }
        } else {
            LazyColumn(modifier = Modifier.padding(padding).fillMaxWidth()) {
                items(fields, key = { it.id }) { def ->
                    CustomFieldRow(def, sectionLabel = sections.firstOrNull { it.id == (def.sectionId.ifBlank { "additional" }) }?.label, scope = scope) { onEdit(def.id) }
                }
            }
        }
    }
}

@Composable
private fun CustomFieldRow(def: CustomFieldDef, sectionLabel: String?, scope: String, onClick: () -> Unit) {
    ListItem(
        headlineContent = { Text(def.label + if (def.mandatory) " *" else "") },
        supportingContent = {
            Text(
                buildString {
                    append(def.type.name.lowercase().replaceFirstChar { it.uppercase() })
                    append(if (def.mandatory) " · Required" else " · Optional")
                    if (scope != "finance" && sectionLabel != null) append(" · $sectionLabel")
                }
            )
        },
        modifier = Modifier.clickable(onClick = onClick)
    )
    Divider()
}
