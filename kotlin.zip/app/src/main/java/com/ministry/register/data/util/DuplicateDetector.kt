package com.ministry.register.data.util

import com.ministry.register.data.db.entity.MemberEntity
import com.ministry.register.data.db.entity.TransactionEntity

object DuplicateDetector {

    /** Same name + same date of birth (case-insensitive), excluding the record being edited. */
    fun findMemberDuplicate(
        candidate: MemberEntity,
        all: List<MemberEntity>,
        excludeId: String?
    ): MemberEntity? {
        val name = candidate.name.trim().lowercase()
        if (name.isBlank()) return null
        return all.firstOrNull {
            it.id != excludeId &&
                it.name.trim().lowercase() == name &&
                it.dob == candidate.dob
        }
    }

    /** Same kind + date + amount + category, excluding the record being edited. */
    fun findTransactionDuplicate(
        candidate: TransactionEntity,
        all: List<TransactionEntity>,
        excludeId: String?
    ): TransactionEntity? {
        return all.firstOrNull {
            it.id != excludeId &&
                it.kind == candidate.kind &&
                it.date == candidate.date &&
                it.amount == candidate.amount &&
                it.category.equals(candidate.category, ignoreCase = true)
        }
    }
}
