package com.ministry.register.ui.dashboard

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ministry.register.data.db.entity.TransactionEntity
import com.ministry.register.data.db.entity.TxnKind
import com.ministry.register.data.repository.MemberRepository
import com.ministry.register.data.repository.TransactionRepository
import com.ministry.register.data.settings.AppSettings
import com.ministry.register.data.settings.SettingsRepository
import com.ministry.register.data.util.AgeUtils
import com.ministry.register.ui.components.SectionDivider
import com.ministry.register.ui.components.SheetCard
import com.ministry.register.ui.components.StatChip
import com.ministry.register.ui.theme.ExpenseColor
import com.ministry.register.ui.theme.IncomeColor
import com.ministry.register.ui.theme.MutedColor
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Locale

data class DashboardUiState(
    val memberCount: Int = 0,
    val expiringSoonCount: Int = 0,
    val monthIncome: Double = 0.0,
    val monthExpense: Double = 0.0,
    val recent: List<TransactionEntity> = emptyList(),
    val settings: AppSettings = AppSettings(),
    val isLoading: Boolean = true
)

class DashboardViewModel(
    private val memberRepository: MemberRepository,
    private val transactionRepository: TransactionRepository,
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    private val _state = MutableStateFlow(DashboardUiState())
    val state: StateFlow<DashboardUiState> = _state.asStateFlow()

    init { reload() }

    fun reload() {
        viewModelScope.launch {
            val settings = settingsRepository.current()
            val members = memberRepository.getAll()
            val monthPrefix = AgeUtils.todayIso().substring(0, 7)
            val income = transactionRepository.sumForMonth(TxnKind.INCOME, monthPrefix)
            val expense = transactionRepository.sumForMonth(TxnKind.EXPENSE, monthPrefix)
            val expiring = members.count {
                it.membershipType == "Regular" &&
                    (AgeUtils.daysUntil(it.membershipExpiry)?.let { d -> d in 0..settings.renewalWarningDays } ?: false)
            }
            val recent = transactionRepository.getAll().take(8)
            _state.value = DashboardUiState(members.size, expiring, income, expense, recent, settings, isLoading = false)
        }
    }
}

private fun formatMoney(amount: Double, symbol: String): String {
    val nf = NumberFormat.getNumberInstance(Locale.US)
    nf.minimumFractionDigits = 2
    nf.maximumFractionDigits = 2
    return "$symbol ${nf.format(amount)}"
}

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(viewModel: DashboardViewModel) {
    val state by viewModel.state.collectAsState()

    Scaffold(topBar = { TopAppBar(title = { Text(state.settings.ministryName.ifBlank { "Dashboard" }) }) }) { padding ->
        LazyColumn(modifier = Modifier.padding(padding).fillMaxWidth().padding(14.dp)) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(bottom = 14.dp)) {
                    StatChip("Members", state.memberCount.toString(), modifier = Modifier.weight(1f))
                    StatChip("Renewals Due", state.expiringSoonCount.toString(), modifier = Modifier.weight(1f))
                }

                SectionDivider("This Month")
                SheetCard(modifier = Modifier.padding(bottom = 14.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Income", color = MutedColor)
                        Text(formatMoney(state.monthIncome, state.settings.currencySymbol), color = IncomeColor, fontWeight = FontWeight.Bold)
                    }
                    Row(modifier = Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Expenses", color = MutedColor)
                        Text(formatMoney(state.monthExpense, state.settings.currencySymbol), color = ExpenseColor, fontWeight = FontWeight.Bold)
                    }
                    Divider(modifier = Modifier.padding(vertical = 8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Net", fontWeight = FontWeight.Bold)
                        Text(
                            formatMoney(state.monthIncome - state.monthExpense, state.settings.currencySymbol),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                SectionDivider("Recent Activity")
            }
            if (state.recent.isEmpty()) {
                item { Text("No recent finance activity.", color = MutedColor, modifier = Modifier.padding(vertical = 12.dp)) }
            } else {
                items(state.recent, key = { it.id }) { txn ->
                    SheetCard(modifier = Modifier.padding(bottom = 8.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text(txn.category, fontWeight = FontWeight.SemiBold)
                                Text(txn.date, color = MutedColor, style = MaterialTheme.typography.labelSmall)
                            }
                            Text(
                                formatMoney(txn.amount, state.settings.currencySymbol),
                                color = if (txn.kind == TxnKind.INCOME) IncomeColor else ExpenseColor,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(80.dp)) }
        }
    }
}
