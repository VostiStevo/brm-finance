package com.ministry.register.ui.lock

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.ministry.register.ui.components.AppTextField
import com.ministry.register.ui.components.SheetCard
import com.ministry.register.ui.theme.Cover2
import com.ministry.register.ui.theme.ExpenseColor
import com.ministry.register.ui.theme.Page

@Composable
fun LockScreen(viewModel: LockViewModel, onUnlocked: () -> Unit) {
    val state by viewModel.state.collectAsState()

    LaunchedEffect(state.stage) {
        if (state.stage == LockStage.UNLOCKED) onUnlocked()
    }

    Box(
        modifier = Modifier.fillMaxSize().background(Cover2),
        contentAlignment = Alignment.Center
    ) {
        when (state.stage) {
            LockStage.LOADING -> CircularProgressIndicator()
            LockStage.SETUP -> SetupCard(state, viewModel)
            LockStage.LOGIN -> LoginCard(state, viewModel)
            LockStage.FORGOT_QUESTION -> RecoveryCard(state, viewModel)
            LockStage.UNLOCKED -> {}
        }
    }
}

@Composable
private fun SetupCard(state: LockUiState, viewModel: LockViewModel) {
    var password by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var question by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf("") }

    SheetCard(modifier = Modifier.padding(24.dp)) {
        Text("Secure ${state.ministryName.ifBlank { "Your Register" }}", style = MaterialTheme.typography.titleLarge)
        Text("Set a password to protect member and finance data on this device.", modifier = Modifier.padding(top = 4.dp, bottom = 16.dp))

        AppTextField("Password", password, { password = it }, modifier = Modifier.padding(bottom = 10.dp))
        AppTextField("Confirm Password", confirm, { confirm = it }, modifier = Modifier.padding(bottom = 10.dp))
        AppTextField("Recovery Question", question, { question = it }, placeholder = "e.g. Name of your first church?", modifier = Modifier.padding(bottom = 10.dp))
        AppTextField("Recovery Answer", answer, { answer = it }, modifier = Modifier.padding(bottom = 10.dp))

        if (state.errorMessage != null) {
            Text(state.errorMessage, color = ExpenseColor, modifier = Modifier.padding(bottom = 8.dp))
        }
        Button(
            onClick = {
                if (password != confirm) return@Button
                viewModel.submitSetup(password, question, answer)
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Create Password") }
    }
}

@Composable
private fun LoginCard(state: LockUiState, viewModel: LockViewModel) {
    var password by remember { mutableStateOf("") }
    val lockedUntil = state.attempts.lockedUntil
    val isLocked = lockedUntil != null && lockedUntil > System.currentTimeMillis()

    SheetCard(modifier = Modifier.padding(24.dp)) {
        Text(state.ministryName.ifBlank { "Ministry Register" }, style = MaterialTheme.typography.titleLarge)
        Text("Enter your password to continue", modifier = Modifier.padding(top = 4.dp, bottom = 16.dp))

        AppTextField(
            "Password", password, { password = it },
            modifier = Modifier.padding(bottom = 10.dp)
        )

        if (state.errorMessage != null) {
            Text(state.errorMessage, color = ExpenseColor, modifier = Modifier.padding(bottom = 8.dp))
        }

        Button(
            onClick = { viewModel.submitLogin(password) },
            enabled = !isLocked,
            modifier = Modifier.fillMaxWidth()
        ) { Text("Unlock") }

        TextButton(onClick = { viewModel.goToForgotPassword() }, modifier = Modifier.padding(top = 6.dp)) {
            Text("Forgot password?")
        }
    }
}

@Composable
private fun RecoveryCard(state: LockUiState, viewModel: LockViewModel) {
    var answer by remember { mutableStateOf("") }
    var newPassword by remember { mutableStateOf("") }

    SheetCard(modifier = Modifier.padding(24.dp)) {
        Text("Reset Password", style = MaterialTheme.typography.titleLarge)
        Text(state.securityQuestion, modifier = Modifier.padding(top = 4.dp, bottom = 12.dp))

        AppTextField("Your Answer", answer, { answer = it }, modifier = Modifier.padding(bottom = 10.dp))
        AppTextField("New Password", newPassword, { newPassword = it }, modifier = Modifier.padding(bottom = 10.dp))

        if (state.errorMessage != null) {
            Text(state.errorMessage, color = ExpenseColor, modifier = Modifier.padding(bottom = 8.dp))
        }

        Button(onClick = { viewModel.submitRecoveryAnswer(answer, newPassword) }, modifier = Modifier.fillMaxWidth()) {
            Text("Reset Password")
        }
        TextButton(onClick = { viewModel.backToLogin() }) { Text("Back to login") }
    }
}
