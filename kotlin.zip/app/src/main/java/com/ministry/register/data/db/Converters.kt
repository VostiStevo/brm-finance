package com.ministry.register.data.db

import androidx.room.TypeConverter
import com.ministry.register.data.db.entity.TxnKind

class Converters {
    @TypeConverter
    fun fromTxnKind(kind: TxnKind): String = kind.name

    @TypeConverter
    fun toTxnKind(value: String): TxnKind = TxnKind.valueOf(value)
}
