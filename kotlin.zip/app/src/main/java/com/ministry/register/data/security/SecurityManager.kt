package com.ministry.register.data.security

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.ministry.register.data.settings.SettingsRepository
import kotlinx.coroutines.flow.first
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

private val Context.securityStore by preferencesDataStore(name = "security_state")
private val ATTEMPTS_KEY = intPreferencesKey("failed_attempts")
private val LOCKOUT_UNTIL_KEY = longPreferencesKey("lockout_until")

const val MAX_ATTEMPTS = 5
const val LOCKOUT_MINUTES = 15L

data class AttemptStatus(val remaining: Int, val lockedUntil: Long?)

/**
 * Mirrors the web app's lock screen: a password, an optional security
 * question for recovery, and a failed-attempt counter that locks the app
 * out for a cooldown period. Nothing plaintext is ever persisted — only
 * salted PBKDF2 hashes.
 */
class SecurityManager(
    private val context: Context,
    private val settingsRepository: SettingsRepository
) {
    fun hash(secret: String, saltHex: String): String {
        val salt = hexToBytes(saltHex)
        val spec = PBEKeySpec(secret.toCharArray(), salt, 120_000, 256)
        val key = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec)
        return bytesToHex(key.encoded)
    }

    fun newSalt(): String {
        val bytes = ByteArray(16)
        SecureRandom().nextBytes(bytes)
        return bytesToHex(bytes)
    }

    suspend fun isSecurityEnabled(): Boolean = settingsRepository.current().securityEnabled

    suspend fun setUpPassword(password: String, question: String, answer: String) {
        val pwSalt = newSalt()
        val ansSalt = newSalt()
        settingsRepository.update {
            it.copy(
                securityEnabled = true,
                securityPasswordSalt = pwSalt,
                securityPasswordHash = hash(password, pwSalt),
                securityQuestion = question,
                securityAnswerSalt = ansSalt,
                securityAnswerHash = hash(answer.trim().lowercase(), ansSalt)
            )
        }
    }

    suspend fun changePassword(newPassword: String) {
        val pwSalt = newSalt()
        settingsRepository.update {
            it.copy(securityPasswordSalt = pwSalt, securityPasswordHash = hash(newPassword, pwSalt))
        }
    }

    suspend fun changeSecurityQuestion(question: String, answer: String) {
        val ansSalt = newSalt()
        settingsRepository.update {
            it.copy(securityQuestion = question, securityAnswerSalt = ansSalt, securityAnswerHash = hash(answer.trim().lowercase(), ansSalt))
        }
    }

    suspend fun verifyPassword(input: String): Boolean {
        val s = settingsRepository.current()
        if (s.securityPasswordHash.isEmpty()) return false
        return hash(input, s.securityPasswordSalt) == s.securityPasswordHash
    }

    suspend fun verifyAnswer(input: String): Boolean {
        val s = settingsRepository.current()
        if (s.securityAnswerHash.isEmpty()) return false
        return hash(input.trim().lowercase(), s.securityAnswerSalt) == s.securityAnswerHash
    }

    suspend fun disableSecurity() {
        settingsRepository.update {
            it.copy(
                securityEnabled = false,
                securityPasswordHash = "", securityPasswordSalt = "",
                securityQuestion = "", securityAnswerHash = "", securityAnswerSalt = ""
            )
        }
        clearAttempts()
    }

    // ---- Failed-attempt lockout ----

    suspend fun attemptStatus(): AttemptStatus {
        val prefs = context.securityStore.data.first()
        val failed = prefs[ATTEMPTS_KEY] ?: 0
        val lockUntil = prefs[LOCKOUT_UNTIL_KEY]
        val active = lockUntil != null && lockUntil > System.currentTimeMillis()
        return AttemptStatus(remaining = (MAX_ATTEMPTS - failed).coerceAtLeast(0), lockedUntil = if (active) lockUntil else null)
    }

    suspend fun recordFailedAttempt(): AttemptStatus {
        context.securityStore.edit { prefs ->
            val failed = (prefs[ATTEMPTS_KEY] ?: 0) + 1
            prefs[ATTEMPTS_KEY] = failed
            if (failed >= MAX_ATTEMPTS) {
                prefs[LOCKOUT_UNTIL_KEY] = System.currentTimeMillis() + LOCKOUT_MINUTES * 60_000
            }
        }
        return attemptStatus()
    }

    suspend fun clearAttempts() {
        context.securityStore.edit { prefs ->
            prefs[ATTEMPTS_KEY] = 0
            prefs.remove(LOCKOUT_UNTIL_KEY)
        }
    }

    private fun bytesToHex(bytes: ByteArray): String = bytes.joinToString("") { "%02x".format(it) }
    private fun hexToBytes(hex: String): ByteArray =
        ByteArray(hex.length / 2) { i -> ((Character.digit(hex[i * 2], 16) shl 4) + Character.digit(hex[i * 2 + 1], 16)).toByte() }
}
