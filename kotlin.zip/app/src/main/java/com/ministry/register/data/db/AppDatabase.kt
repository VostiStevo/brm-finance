package com.ministry.register.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.ministry.register.data.db.dao.MemberDao
import com.ministry.register.data.db.dao.TransactionDao
import com.ministry.register.data.db.entity.MemberEntity
import com.ministry.register.data.db.entity.TransactionEntity

@Database(
    entities = [MemberEntity::class, TransactionEntity::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun memberDao(): MemberDao
    abstract fun transactionDao(): TransactionDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "ministry_register.db"
                ).build().also { INSTANCE = it }
            }
    }
}
