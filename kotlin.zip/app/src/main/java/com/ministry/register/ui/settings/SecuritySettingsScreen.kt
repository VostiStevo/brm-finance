package com.ministry.register.ui.settings

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.ministry.register.ui.components.AppTextField
import com.ministry.register.ui.components.ConfirmDialog
import com.ministry.register.ui.components.SectionDivider
import com.ministry.register.ui.components.SheetCard

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SecuritySettingsScreen(viewModel: SettingsViewModel, onBack: () -> Unit, onDisabled: () -> Unit) {
    val settings by viewModel.settings.collectAsState()
    var newPassword by remember { mutableStateOf("") }
    var newQuestion by remember(settings.securityQuestion) { mutableStateOf(settings.securityQuestion) }
    var newAnswer by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    var confirmDisable by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Security") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") } }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxWidth().padding(14.dp)) {
            SectionDivider("Change Password")
            SheetCard(modifier = Modifier.padding(bottom = 14.dp)) {
                AppTextField("New Password", newPassword, { newPassword = it }, modifier = Modifier.padding(bottom = 10.dp))
                Button(
                    onClick = { viewModel.changePassword(newPassword) { _, msg -> message = msg; if (msg.startsWith("Password updated")) newPassword = "" } },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Update Password") }
            }

            SectionDivider("Recovery Question")
            SheetCard(modifier = Modifier.padding(bottom = 14.dp)) {
                AppTextField("Question", newQuestion, { newQuestion = it }, modifier = Modifier.padding(bottom = 10.dp))
                AppTextField("Answer", newAnswer, { newAnswer = it }, modifier = Modifier.padding(bottom = 10.dp))
                Button(
                    onClick = { viewModel.changeSecurityQuestion(newQuestion, newAnswer) { _, msg -> message = msg; if (msg.startsWith("Recovery")) newAnswer = "" } },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Update Recovery Question") }
            }

            SectionDivider("Danger Zone")
            SheetCard {
                Text("Turning off the app lock removes password protection entirely.", modifier = Modifier.padding(bottom = 10.dp))
                OutlinedButton(onClick = { confirmDisable = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("Disable App Lock", color = com.ministry.register.ui.theme.ExpenseColor)
                }
            }

            message?.let { Text(it, modifier = Modifier.padding(top = 12.dp)) }
        }
    }

    if (confirmDisable) {
        ConfirmDialog(
            message = "Disable the app lock? Anyone with access to this device will be able to open the app.",
            confirmLabel = "Disable",
            onConfirm = { confirmDisable = false; viewModel.disableSecurity(onDisabled) },
            onDismiss = { confirmDisable = false }
        )
    }
}
