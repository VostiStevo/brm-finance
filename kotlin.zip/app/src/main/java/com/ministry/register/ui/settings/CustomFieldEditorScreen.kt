package com.ministry.register.ui.settings

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.ministry.register.data.settings.CustomFieldDef
import com.ministry.register.data.settings.FieldType
import com.ministry.register.data.util.Ids
import com.ministry.register.ui.components.AppDropdownField
import com.ministry.register.ui.components.AppTextField
import com.ministry.register.ui.components.ConfirmDialog

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomFieldEditorScreen(
    viewModel: SettingsViewModel,
    scope: String,
    fieldId: String?,
    onDone: () -> Unit,
    onBack: () -> Unit
) {
    val settings by viewModel.settings.collectAsState()
    val existingList = if (scope == "finance") settings.financeCustomFields else settings.customFields
    val existing = existingList.firstOrNull { it.id == fieldId }

    var label by remember(existing) { mutableStateOf(existing?.label ?: "") }
    var type by remember(existing) { mutableStateOf(existing?.type ?: FieldType.TEXT) }
    var optionsText by remember(existing) { mutableStateOf(existing?.options?.joinToString("\n") ?: "") }
    var mandatory by remember(existing) { mutableStateOf(existing?.mandatory ?: false) }
    var subLabel by remember(existing) { mutableStateOf(existing?.subLabel ?: "") }
    var condFieldId by remember(existing) { mutableStateOf(existing?.condField ?: "") }
    var condValue by remember(existing) { mutableStateOf(existing?.condValue ?: "") }
    var sectionId by remember(existing) { mutableStateOf(existing?.sectionId ?: "additional") }
    var confirmDelete by remember { mutableStateOf(false) }

    val otherFields = existingList.filter { it.id != fieldId }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (existing == null) "Add Custom Field" else "Edit Custom Field") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") } }
            )
        },
        bottomBar = {
            BottomAppBar {
                Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
                    Button(
                        onClick = {
                            val def = CustomFieldDef(
                                id = existing?.id ?: Ids.next(),
                                label = label.trim(),
                                type = type,
                                options = optionsText.lines().map { it.trim() }.filter { it.isNotBlank() },
                                mandatory = mandatory,
                                subLabel = subLabel.trim(),
                                condField = condFieldId,
                                condValue = condValue.trim(),
                                sectionId = if (scope == "finance") "" else sectionId
                            )
                            viewModel.saveCustomField(scope, def)
                            onDone()
                        },
                        enabled = label.isNotBlank(),
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Save Field") }

                    if (existing != null) {
                        TextButton(onClick = { confirmDelete = true }, modifier = Modifier.fillMaxWidth()) {
                            Text("Delete Field", color = com.ministry.register.ui.theme.ExpenseColor)
                        }
                    }
                }
            }
        }
    ) { padding ->
        LazyColumn(modifier = Modifier.padding(padding).fillMaxWidth().padding(14.dp)) {
            item {
                AppTextField("Field Label", label, { label = it }, placeholder = "e.g. Occupation", modifier = Modifier.padding(bottom = 10.dp))

                AppDropdownField(
                    "Input Type", FieldType.values().toList(), type,
                    { it.name.lowercase().replaceFirstChar { c -> c.uppercase() } },
                    { type = it },
                    modifier = Modifier.padding(bottom = 10.dp)
                )

                if (scope != "finance") {
                    AppDropdownField(
                        "Header", settings.memberFormSections, settings.memberFormSections.firstOrNull { it.id == sectionId },
                        { it.label }, { sectionId = it.id },
                        modifier = Modifier.padding(bottom = 10.dp)
                    )
                }

                if (type == FieldType.LIST || type == FieldType.REPEATING) {
                    AppTextField(
                        if (type == FieldType.REPEATING) "Type Options (one per line)" else "List Options (one per line)",
                        optionsText, { optionsText = it }, singleLine = false, modifier = Modifier.padding(bottom = 10.dp)
                    )
                }
                if (type == FieldType.REPEATING) {
                    AppTextField("Value Column Label", subLabel, { subLabel = it }, placeholder = "e.g. Number", modifier = Modifier.padding(bottom = 10.dp))
                }

                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically, modifier = Modifier.padding(bottom = 10.dp)) {
                    Switch(checked = mandatory, onCheckedChange = { mandatory = it })
                    Text("Required field", modifier = Modifier.padding(start = 8.dp))
                }

                if (otherFields.isNotEmpty()) {
                    Text("Show this field only when…", style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(bottom = 6.dp))
                    AppDropdownField(
                        "Trigger Field", listOf<CustomFieldDef?>(null) + otherFields,
                        otherFields.firstOrNull { it.id == condFieldId },
                        { it?.label ?: "None (always show)" },
                        { condFieldId = it?.id ?: "" },
                        modifier = Modifier.padding(bottom = 10.dp)
                    )
                    if (condFieldId.isNotBlank()) {
                        AppTextField("Equals Value", condValue, { condValue = it }, modifier = Modifier.padding(bottom = 10.dp))
                    }
                }

                Spacer(Modifier.height(100.dp))
            }
        }
    }

    if (confirmDelete && existing != null) {
        ConfirmDialog(
            message = "Delete the \"${existing.label}\" field? Existing answers for it will remain on each record but won't be shown anymore.",
            onConfirm = { confirmDelete = false; viewModel.deleteCustomField(scope, existing.id); onDone() },
            onDismiss = { confirmDelete = false }
        )
    }
}
