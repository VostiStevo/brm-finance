package com.ministry.register.data.db.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Serializable
data class FamilyMember(
    val name: String = "",
    val relation: String = "Spouse"
)

@Serializable
data class RepeatingRow(
    val type: String = "",
    val value: String = ""
)

/**
 * A member/congregant record. Custom field answers are stored as a JSON map
 * (fieldDefId -> value) so the schema doesn't need to change whenever an
 * admin adds/removes a custom field from Settings. Repeating-type custom
 * fields store a JSON list of RepeatingRow under the same field id.
 */
@Entity(tableName = "members")
@Serializable
data class MemberEntity(
    @PrimaryKey val id: String,
    val name: String = "",
    val gender: String = "Male",
    val dob: String = "",           // ISO yyyy-MM-dd
    val regNo: String = "",
    val membershipType: String = "Regular",
    val joined: String = "",        // ISO yyyy-MM-dd
    val membershipExpiry: String = "", // ISO yyyy-MM-dd, only used when membershipType == Regular
    val familyMembersJson: String = "[]",   // List<FamilyMember>
    val notes: String = "",
    val photoPath: String? = null,
    val customDataJson: String = "{}",      // Map<String, String> plus repeating fields as JSON-encoded lists
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
