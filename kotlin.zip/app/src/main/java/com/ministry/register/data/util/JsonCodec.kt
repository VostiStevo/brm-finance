package com.ministry.register.data.util

import com.ministry.register.data.db.entity.FamilyMember
import com.ministry.register.data.db.entity.RepeatingRow
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.builtins.MapSerializer
import kotlinx.serialization.builtins.serializer

object JsonCodec {
    val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    fun decodeCustomData(raw: String): Map<String, String> =
        runCatching { json.decodeFromString(MapSerializer(String.serializer(), String.serializer()), raw) }
            .getOrDefault(emptyMap())

    fun encodeCustomData(map: Map<String, String>): String =
        json.encodeToString(MapSerializer(String.serializer(), String.serializer()), map)

    fun decodeFamilyMembers(raw: String): List<FamilyMember> =
        runCatching { json.decodeFromString(ListSerializer(FamilyMember.serializer()), raw) }
            .getOrDefault(emptyList())

    fun encodeFamilyMembers(list: List<FamilyMember>): String =
        json.encodeToString(ListSerializer(FamilyMember.serializer()), list)

    fun decodeRepeatingRows(raw: String): List<RepeatingRow> =
        runCatching { json.decodeFromString(ListSerializer(RepeatingRow.serializer()), raw) }
            .getOrDefault(emptyList())

    fun encodeRepeatingRows(list: List<RepeatingRow>): String =
        json.encodeToString(ListSerializer(RepeatingRow.serializer()), list)
}
