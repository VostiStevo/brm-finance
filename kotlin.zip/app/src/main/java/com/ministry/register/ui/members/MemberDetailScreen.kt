package com.ministry.register.ui.members

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ministry.register.data.db.entity.MemberEntity
import com.ministry.register.data.repository.MemberRepository
import com.ministry.register.data.settings.AppSettings
import com.ministry.register.data.settings.SettingsRepository
import com.ministry.register.data.util.AgeUtils
import com.ministry.register.data.util.JsonCodec
import com.ministry.register.ui.components.ConfirmDialog
import com.ministry.register.ui.components.DetailRow
import com.ministry.register.ui.components.SectionDivider
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class MemberDetailUiState(
    val member: MemberEntity? = null,
    val settings: AppSettings = AppSettings(),
    val isLoading: Boolean = true
)

class MemberDetailViewModel(
    private val repository: MemberRepository,
    private val settingsRepository: SettingsRepository,
    private val memberId: String
) : ViewModel() {
    private val _state = MutableStateFlow(MemberDetailUiState())
    val state: StateFlow<MemberDetailUiState> = _state.asStateFlow()

    init {
        reload()
    }

    fun reload() {
        viewModelScope.launch {
            _state.value = MemberDetailUiState(
                member = repository.getById(memberId),
                settings = settingsRepository.current(),
                isLoading = false
            )
        }
    }

    fun delete(onDone: () -> Unit) {
        viewModelScope.launch { repository.delete(memberId); onDone() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MemberDetailScreen(
    viewModel: MemberDetailViewModel,
    onBack: () -> Unit,
    onEdit: (String) -> Unit,
    onDeleted: () -> Unit
) {
    val state by viewModel.state.collectAsState()
    var confirmDelete by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(state.member?.name ?: "Member") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") } },
                actions = {
                    state.member?.let { m ->
                        IconButton(onClick = { onEdit(m.id) }) { Icon(Icons.Default.Edit, contentDescription = "Edit") }
                        IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Default.Delete, contentDescription = "Delete") }
                    }
                }
            )
        }
    ) { padding ->
        val member = state.member
        if (state.isLoading || member == null) {
            Box(Modifier.padding(padding).fillMaxSize(), contentAlignment = androidx.compose.ui.Alignment.Center) {
                if (state.isLoading) CircularProgressIndicator() else Text("Member not found.")
            }
            return@Scaffold
        }

        val age = AgeUtils.calcAge(member.dob)
        val customData = JsonCodec.decodeCustomData(member.customDataJson)
        val familyMembers = JsonCodec.decodeFamilyMembers(member.familyMembersJson)

        LazyColumn(modifier = Modifier.padding(padding).fillMaxWidth().padding(horizontal = 14.dp)) {
            item {
                state.settings.memberFormSections.forEach { section ->
                    when (section.id) {
                        "basic" -> {
                            SectionDivider(section.label)
                            if (state.settings.memberFormFields["regNo"] != false) DetailRow("Registration Number", member.regNo)
                            DetailRow("Gender", member.gender)
                            DetailRow("Date of Birth", member.dob)
                            DetailRow("Age", age?.let { "$it — ${AgeUtils.ageGroup(age, state.settings.ageGroupBoundaries)}" } ?: "—")
                        }
                        "membership" -> {
                            val showType = state.settings.memberFormFields["membershipType"] != false
                            val showJoined = state.settings.memberFormFields["joined"] != false
                            if (showType || showJoined) {
                                SectionDivider(section.label)
                                if (showType) {
                                    DetailRow("Membership Type", member.membershipType)
                                    if (member.membershipType == "Regular") DetailRow("Membership Expiry", member.membershipExpiry)
                                }
                                if (showJoined) DetailRow("Date Joined", member.joined)
                            }
                        }
                        else -> {
                            val fields = state.settings.customFields.filter { (it.sectionId.ifBlank { "additional" }) == section.id }
                            val nonEmpty = fields.filter { customData[it.id]?.isNotBlank() == true }
                            if (nonEmpty.isNotEmpty()) {
                                SectionDivider(section.label)
                                nonEmpty.forEach { DetailRow(it.label, customData[it.id] ?: "") }
                            }
                        }
                    }
                }

                if (state.settings.memberFormFields["family"] != false && familyMembers.isNotEmpty()) {
                    SectionDivider("Family / Household")
                    familyMembers.forEach { DetailRow(it.relation, it.name) }
                }

                if (state.settings.memberFormFields["notes"] != false && member.notes.isNotBlank()) {
                    SectionDivider("Notes")
                    Text(member.notes, modifier = Modifier.padding(bottom = 16.dp))
                }

                Spacer(Modifier.height(40.dp))
            }
        }
    }

    if (confirmDelete) {
        ConfirmDialog(
            message = "Delete this member record? This cannot be undone.",
            onConfirm = { confirmDelete = false; viewModel.delete(onDeleted) },
            onDismiss = { confirmDelete = false }
        )
    }
}
