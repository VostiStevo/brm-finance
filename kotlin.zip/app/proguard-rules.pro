# Keep Room-generated code and kotlinx.serialization models intact.
-keep class com.ministry.register.data.** { *; }
-keepattributes *Annotation*
