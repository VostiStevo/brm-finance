# Ministry Register — Android (Kotlin)

A native Android rewrite of the Ministry Register web app, built from scratch
as a new Kotlin + Jetpack Compose project. It covers every feature of the
original app **except charts**, per request.

## Stack

- **Kotlin** + **Jetpack Compose** (Material 3) for UI
- **Room** for members and finance records
- **DataStore (Preferences)** storing app settings as a single JSON blob
  (mirrors how the web app kept one `settings` object in `localStorage`)
- **Navigation-Compose** for screen routing
- **kotlinx.serialization** for JSON (settings blob + full backup/restore file)
- Native `android.graphics.pdf.PdfDocument` for PDF reports — no external
  PDF library needed
- Manual dependency injection via a single `Application` subclass
  (`MinistryApp`) — no Hilt/Dagger, to keep the project easy to read and
  modify without extra build complexity

No charting library is included anywhere, and the Dashboard is numbers/cards
only (no chart canvas), matching the instruction to leave charts out.

## Project layout

```
app/src/main/java/com/ministry/register/
  data/
    db/            Room entities, DAOs, database
    settings/      AppSettings model + DataStore-backed repository
    security/      Password/security-question hashing, attempt lockout
    repository/    MemberRepository, TransactionRepository
    util/          RegNoGenerator, DuplicateDetector, PdfReportGenerator,
                    CsvExporter, BackupManager, AgeUtils, JsonCodec
  ui/
    theme/         Colors/typography matching the original app's palette
    components/    Shared building blocks (cards, dividers, form fields…)
    lock/          App-lock setup/login/recovery screens
    dashboard/     Summary stats + recent activity (no charts)
    members/       List, detail, and dynamic add/edit form
    finances/      Income/expense list and form
    reports/       PDF/CSV export + full JSON backup & restore
    settings/      General settings, categories, custom fields, form
                    sections, security settings
    AppRoot.kt     Navigation graph + bottom nav shell
  MainActivity.kt
  MinistryApp.kt   Manual DI container
```

## Feature parity with the web app

| Web app feature | Where it lives here |
|---|---|
| Member records with custom fields & form sections | `ui/members/*`, `data/settings/AppSettings.kt` |
| Registration number auto-suggest that ignores deleted records | `data/util/RegNoGenerator.kt` (same logic as the fix applied to the web app) |
| Editable registration number field | `MemberFormScreen.kt` — plain text field, never locked |
| Family/household rows | `MemberFormViewModel` + `FamilyRow` in `MemberFormScreen.kt` |
| Duplicate-record detection (members & finance) | `data/util/DuplicateDetector.kt` |
| Income/expense ledger with categories & pay methods | `ui/finances/*` |
| Custom fields (text/number/date/email/list/repeating, conditional display) | `CustomFieldEditorScreen.kt`, rendered in both member and finance forms |
| Membership form section headers (add/rename/reorder/delete) | `FormSectionsScreen.kt` |
| PDF export (member records, ledger) | `data/util/PdfReportGenerator.kt` |
| CSV/Excel export | `data/util/CsvExporter.kt` |
| Full backup & restore (JSON) | `data/util/BackupManager.kt`, `ReportsScreen.kt` |
| App lock: password + security question + attempt lockout | `data/security/SecurityManager.kt`, `ui/lock/*` |
| Settings: age-group boundaries, renewal warning window, categories, field toggles | `SettingsScreen.kt` |
| Dashboard stats | `DashboardScreen.kt` (numbers/cards, **no chart**) |
| Charts | **Intentionally omitted** |

## Building it

This was written in a sandboxed environment with **no Android SDK, no
Gradle, and no network access** — so I could not compile or run it here.
I wrote it carefully against standard, well-documented AndroidX/Compose/Room
APIs, double-checked types and imports by hand, and fixed several real bugs
I found on review (a couple of missing `@OptIn` annotations for experimental
Material 3 APIs, a nullable/non-null mismatch, an invalid `remember` call
outside a composable). That said, **it has not been build-verified**, unlike
the web app changes earlier in this conversation which I ran through actual
test harnesses.

To build it:

1. Open the `MinistryRegister/` folder in Android Studio (Koala or newer).
   Studio will generate the Gradle wrapper jar automatically on first sync —
   the `gradle-wrapper.properties` file is already there pointing at Gradle 8.7.
2. Let Gradle sync and download dependencies (needs network access on your
   machine).
3. Run on a device/emulator with API 26+.
4. First launch prompts you to set an app password and a recovery question
   (mirrors the web app's mandatory first-run security setup).

If Studio reports any errors, they're most likely small — a renamed API in a
slightly different library version, a missing import — normal first-build
friction for a hand-written project of this size, not structural problems.

## Deliberate simplifications vs. the web app

- **Reports** use a compact native table renderer instead of the web app's
  jsPDF/autotable layout — same information, plainer styling.
- **Photo capture** for members isn't wired up (the schema has a
  `photoPath` column ready for it — hooking up a camera/gallery picker with
  `ActivityResultContracts.TakePicture` is a small follow-up).
- **Yearly summary / year-over-year comparison** screens from the web app's
  Reports tab weren't ported — the underlying data is all there
  (`TransactionRepository.getBetween`), just no dedicated screen yet.
